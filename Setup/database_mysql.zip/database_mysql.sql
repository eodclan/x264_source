-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 22. Nov 2017 um 18:21
-- Server Version: 5.5.58-0+deb8u1
-- PHP-Version: 5.6.30-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `source`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `userid` int(10) NOT NULL DEFAULT '0',
  `chash` varchar(32) NOT NULL DEFAULT '',
  `lastaccess` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `username` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `baduser` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `accounts`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `addedrequests`
--

CREATE TABLE IF NOT EXISTS `addedrequests` (
`id` int(10) unsigned NOT NULL,
  `requestid` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `addedrequests`
--

INSERT INTO `addedrequests` (`id`, `requestid`, `userid`) VALUES
(1, 1, 1),
(2, 2, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `admincat`
--

CREATE TABLE IF NOT EXISTS `admincat` (
`id` int(3) NOT NULL,
  `catid` int(2) NOT NULL,
  `catname` varchar(20) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `admincat`
--

INSERT INTO `admincat` (`id`, `catid`, `catname`) VALUES
(20, 25, 'Moderator'),
(22, 50, 'Admin'),
(23, 100, 'SysOp'),
(25, 255, 'Developer');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `admincp`
--

CREATE TABLE IF NOT EXISTS `admincp` (
`id` int(3) NOT NULL,
  `bezeichnung` varchar(100) CHARACTER SET latin1 NOT NULL,
  `link` varchar(30) CHARACTER SET latin1 NOT NULL,
  `beschreibung` varchar(500) CHARACTER SET latin1 NOT NULL,
  `color` int(1) NOT NULL,
  `cat` int(2) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=88 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Daten für Tabelle `admincp`
--

INSERT INTO `admincp` (`id`, `bezeichnung`, `link`, `beschreibung`, `color`, `cat`) VALUES
(5, 'Loginversuche', '/maxlogin.php', 'Hier kann man fehlgeschlagene Loginversuche einsehen und IP Adressen ggf. bannen/entbannen.', 3, 21),
(83, 'Manager Verwaltung', 'admin_panel_manager.php', 'Manager Verwaltung', 1, 22),
(8, 'Gast Upload Bonus', '/gubonus.php', 'Hier kann man den Gastupload Bonus einstellen', 3, 24),
(11, 'Verwarnte User', '/warned.php', 'Hier k&ouml;nnen verwarnte User eingesehen und bearbeitet werden', 2, 20),
(17, 'Report', '/showreport.php', 'Gemeldete User', 2, 20),
(58, 'User Klassen Manager', '/classmanager.php', 'Hier gehts zum User Klassen Manager', 3, 25),
(84, 'News bearbeiten', 'news.php', 'News bearbeiten', 1, 22),
(29, 'Unbest&auml;tigte User', 'unco.php', 'Unbest&auml;tigte Useraccounts freischalten und l&ouml;schen', 2, 21),
(33, 'Doppel IPs', '/doppelip.php', 'Hier werden user mit einer Doppel IP aufgelistet die keine Doppelipfreigabe haben', 3, 21),
(34, 'Erlaubte Doppel IPs', '/dipok.php', 'Liste aller erlaubten Doppel IPs', 1, 21),
(36, 'Umfragen', '/addpollnew.php', 'Umfragen erstellen/&auml;ndern/l&ouml;schen', 2, 22),
(39, 'Invites', '/invitesystem.php', 'Invites hinzuf&uuml;gen/entfernen', 3, 24),
(41, 'Kategorien verwalten', '/kategorien.php', 'Hier kann man Tracker Kategorien anlegen/&auml;ndern/l&ouml;schen', 3, 25),
(45, 'Regel best&auml;tigen', '/takeallrules.php', 'Alle User m&uuml;ssen Regeln best&auml;tigen', 2, 24),
(50, 'Peer Anzeige', '/allclients.php', 'Liste aller Peers inklusieve verwendeter Client', 1, 20),
(85, 'Manager Verwaltung Control', 'admin_panel.php', 'Manager Verwaltung Control', 2, 23),
(86, 'Staff Rules Manager', 'staffrulesadmin.php', 'Staff Rules Manager', 3, 23),
(62, 'Navigationsverwaltung', '/navi.php', 'Hier kann man die Navi bearbeiten', 2, 25),
(63, 'Staff Interne Umfrage', '/sysopquestions.php', 'Hier kann man Staffintene Umfragen erstellen und einsehen', 1, 24),
(66, 'Clienten Verwaltung', '/cp_agents.php', 'Hier kann man Clienten erlauben bzw bannen', 3, 25),
(72, 'Nameserver Check', 'nameserver.php', 'IP zur&uuml;ck verfolgung ect', 2, 25),
(71, 'Tracker Config', 'dev_panel.php', 'Hiermit kann man den Tracker per Browser einstellen.', 3, 25),
(87, 'Style System', 'themecp.php', 'Style System', 1, 25),
(74, 'User PM Verwaltung', 'ownerpm.php', 'PM''s Spion und Verwaltung. Vorsicht !! Teilweise AKTION !!', 3, 24),
(77, 'User Foundation System', 'user_foundation.php', 'Ich habe mal eine Such-Routine gebastelt, welche eure Usernamen und die eMail-Addys nach &Auml;hnlichkeiten durchforstet.', 1, 22),
(78, 'Cleanup ACP', 'cleanup_acp.php', 'Cleanup ACP', 3, 25);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `admincpanz`
--

CREATE TABLE IF NOT EXISTS `admincpanz` (
`id` int(3) NOT NULL,
  `userid` int(3) NOT NULL,
  `anz` enum('1','2') NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `admincpanz`
--

INSERT INTO `admincpanz` (`id`, `userid`, `anz`) VALUES
(94, 1, '1');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `admin_categories`
--

CREATE TABLE IF NOT EXISTS `admin_categories` (
`id` int(11) NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `short` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `sort` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `admin_categories`
--

INSERT INTO `admin_categories` (`id`, `name`, `short`, `sort`) VALUES
(5, 'Managers', 'managers', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `admin_questions`
--

CREATE TABLE IF NOT EXISTS `admin_questions` (
`id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `question` text COLLATE latin1_general_ci NOT NULL,
  `answer` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `admin_questions`
--

INSERT INTO `admin_questions` (`id`, `category`, `question`, `answer`) VALUES
(24, 5, 'Manager Verwaltung', '<div class=''x264_wrapper_content_out_mount''>\r\n<h1 class=''x264_im_logo''>Hier sind alle Managers zum Verwalten!</h1>\r\n	<div class=''x264_title_content''>\r\n		<div class=''x264_title_table''><a href=''/faqadmin.php''>FAQ Manager</a></div>\r\n		<div class=''x264_title_table''><a href=''/rulesadmin.php''>Rules Manager</a></div>			\r\n	</div>\r\n</div>\r\n</div>');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `agents`
--

CREATE TABLE IF NOT EXISTS `agents` (
`agent_id` int(10) unsigned NOT NULL,
  `agent_name` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `ins_date` int(10) unsigned NOT NULL DEFAULT '0',
  `aktiv` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=138 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `agents`
--

INSERT INTO `agents` (`agent_id`, `agent_name`, `hits`, `ins_date`, `aktiv`) VALUES
(1, 'rtorrent/0.9.4/0.13.4', 45919982, 1432514593, 1),
(2, 'rtorrent/0.9.3/0.13.3', 18061899, 1432514657, 1),
(3, 'uTorrent/1600', 822153, 1432577108, 1),
(4, 'Transmission/2.82', 4455227, 1432582133, 1),
(5, 'uTorrent/2210(25249)', 28638, 1432586272, 1),
(6, 'Transmission/2.32', 28386, 1432587664, 1),
(7, 'BitTornado/T-0.3.18', 3624377, 1432589731, 1),
(8, 'uTorrent/1610', 1759853, 1432590358, 1),
(9, 'Transmission/2.83', 71612, 1432623620, 1),
(10, 'rtorrent/0.9.2/0.13.2', 270896, 1432651287, 1),
(11, 'uTorrent/2040(21586)', 165864, 1432720939, 1),
(12, 'uTorrent/1500', 183846, 1432928450, 1),
(13, 'uTorrent/3320(30303)', 37094, 1433621527, 1),
(14, 'uTorrent/1850(17414)', 96890, 1433740559, 1),
(15, 'uTorrent/2040(22967)', 211925, 1433927179, 1),
(16, 'uTorrent/3300(29126)', 4438, 1433949341, 1),
(17, 'uTorrent/1840(16150)', 8191, 1434403030, 1),
(18, 'uTorrent/2040(22450)', 458, 1434465304, 1),
(19, 'uTorrent/343(109550954)(40298)', 1050, 1434483787, 1),
(20, 'uTorrent/2210(25302)', 193954, 1434794743, 1),
(21, 'rtorrent/0.8.9/0.12.9', 862, 1434903163, 1),
(22, 'uTorrent/2210(25130)', 68690, 1434997025, 1),
(23, 'uTorrent/3320(30416)', 8928, 1435222627, 1),
(24, 'Transmission/2.84', 4078045, 1435702348, 1),
(25, 'uTorrent/2000(17920)', 15, 1436262097, 1),
(26, 'uTorrent/342(109419170)(39586)', 5, 1436472162, 1),
(27, 'BitTorrent/793(254254778)(40634)', 633, 1436872529, 1),
(28, 'uTorrent/343(109551416)(40760)', 7809, 1437681255, 1),
(29, 'uTorrent/2200(23703)', 40234, 1437831223, 1),
(30, 'uTorrent/3000(26473)', 19454, 1437989601, 1),
(31, 'uTorrent/343(109551289)(40633)', 888, 1438193868, 1),
(32, 'uTorrent/342(109417981)(38397)', 22, 1438862085, 1),
(33, 'uTorrent/2040(21431)', 3919, 1438862158, 1),
(34, 'uTorrent/343(109550600)(39944)', 8, 1439049985, 1),
(35, 'uTorrentMac/1870(40398)', 4791, 1439326958, 1),
(36, 'Transmission/2.52', 19183, 1439475747, 1),
(37, 'uTorrent/3300(29625)', 40, 1439727952, 1),
(38, 'BitTorrent/6200(15918)', 523, 1439742386, 1),
(39, 'uTorrent/344(109682639)(40911)', 1115, 1440171155, 1),
(40, 'uTorrent/1400', 3, 1440508188, 0),
(41, 'uTorrent/2200(24402)', 2712, 1440509651, 1),
(42, 'uTorrent/3200(28581)(embedded)(28581)', 124, 1441731125, 0),
(43, 'uTorrent/345(109813873)(41073)', 344, 1442662432, 1),
(44, 'uTorrent/3000(25683)', 5, 1442909521, 1),
(45, 'uTorrentMac/1870(41006)', 7175, 1443165923, 1),
(46, 'uTorrent/345(109813962)(41162)', 3141, 1443256059, 1),
(47, 'uTorrent/1820', 15672, 1443780320, 1),
(48, 'ACEStream/ACEStream-2.0', 2, 1443820925, 0),
(49, 'Transmission/2.50', 7583, 1444073879, 1),
(50, 'uTorrent/345(109814002)(41202)', 1849, 1444663255, 1),
(51, 'uTorrent/1850(17091)', 337, 1444711019, 1),
(52, 'uTorrent/1770', 4374, 1445453881, 1),
(53, 'uTorrent/340(109148075)(30635)', 215, 1445593974, 1),
(54, 'uTorrent/2040(22150)', 5509, 1445601694, 1),
(55, 'rtorrent/0.9.6/0.13.6', 324650025, 1445784355, 1),
(56, 'BitTorrent/4.1.2', 9, 1446276381, 1),
(57, 'Deluge 1.3.10', 70877, 1446300703, 1),
(58, 'uTorrent/3130(26837)', 149, 1446331455, 1),
(59, 'uTorrent/3200(27886)', 6, 1446403830, 0),
(60, 'Mozilla/5.0 (Windows NT 6.1', 5, 1448099897, 0),
(61, 'uTorrent/3120(26821)', 105455, 1448197817, 1),
(62, 'uTorrent/2210(25110)', 21502, 1448530178, 1),
(63, 'BitTorrent/7700(27987)', 9, 1448745053, 1),
(64, 'uTorrent/345(109814172)(41372)', 8972, 1449010335, 0),
(65, 'uTorrentMac/1870(41339)', 2766, 1449758866, 1),
(66, 'BitTornado/T-0.3.17', 25, 1451038538, 1),
(67, 'libtorrent/0.16.12.0', 12, 1451419925, 1),
(68, 'zetaTorrent 2.6.5', 3, 1451425987, 0),
(69, 'libtorrent/1.0.7.0', 170, 1451427204, 0),
(70, 'uTorrent/2200(23071)', 296936, 1451663365, 1),
(71, 'uTorrent/2030(20664)', 9, 1451663505, 1),
(72, 'uTorrent/1810', 664, 1451663737, 1),
(73, 'BitLord 2.4.2', 2, 1452851486, 1),
(74, 'uTorrent/343(109550753)(40097)', 271, 1454272877, 1),
(75, 'uTorrent/345(109814512)(41712)', 6334, 1454627063, 1),
(76, 'Mozilla/5.0 (Windows NT 10.0', 7, 1454805841, 0),
(77, 'uTorrent/1150', 1, 1455191451, 0),
(78, 'uTorrent/1710', 20, 1455191855, 1),
(79, 'Azureus 2.4.0.2', 263, 1455392858, 1),
(80, 'uTorrent/345(109814601)(41801)', 13, 1455611506, 1),
(81, 'Mozilla/5.0 (Windows NT 6.0', 1, 1455665282, 0),
(82, 'uTorrentMac/1870(41795)', 3128, 1455733685, 1),
(83, 'uTorrent/342(109417535)(37951)', 6, 1455753371, 1),
(84, 'BitTorrent/795(254518001)(41713)', 17481, 1455754742, 1),
(85, 'qBittorrent v3.2.3', 35802, 1456253247, 1),
(86, 'Deluge 1.3.11', 1481, 1457093645, 1),
(87, 'uTorrent/345(109814665)(41865)', 6844, 1457972918, 0),
(88, 'uTorrentMac/1870(41986)', 24740, 1459712737, 1),
(89, 'uTorrent/346(109945966)(42094)', 12449, 1460241933, 0),
(90, 'uTorrent/346(109946050)(42178)', 2254, 1460821940, 0),
(91, 'qBittorrent v3.1.11', 122, 1462196233, 1),
(92, 'Transmission/2.92', 163911, 1462645914, 1),
(93, 'BitTorrent/797(254780763)(42331)', 868, 1462876894, 1),
(94, 'uTorrent/347(110077274)(42330)', 8115, 1463791968, 1),
(95, 'uTorrent/3310(29988)', 6884, 1465113554, 1),
(96, 'uTorrent/3320(30488)', 911, 1466841614, 1),
(97, 'Transmission/1.92', 1, 1467303636, 1),
(98, 'uTorrent/2020(19648)', 102783, 1487103851, 1),
(99, 'uTorrent/349(110340383)(43295)', 3633, 1487184822, 1),
(100, 'Transmission/2.11', 949, 1487246308, 1),
(101, 'uTorrentMac/1870(42417)', 53825, 1488958734, 1),
(102, 'uTorrent/349(110340011)(42923)', 2961, 1489056685, 1),
(103, 'uTorrent/3000(25406)', 3, 1489408569, 1),
(104, 'uTorrent/349(110340476)(43388)', 16943, 1489439366, 1),
(105, 'Deluge 1.3.14', 2829, 1489831333, 1),
(106, 'qBittorrent v3.3.11', 11, 1489855308, 1),
(107, 'Azureus 5.7.5.0', 6494, 1490870761, 1),
(108, 'uTorrent/350(111258172)(43580)', 67512, 1491585145, 1),
(109, 'uTorrent/3000(25454)', 7, 1492516512, 1),
(110, 'uTorrent/349(110340173)(43085)', 2705, 1492521748, 1),
(111, 'uTorrent/342(109414528)(34944)', 20644, 1492538967, 1),
(112, 'uTorrent/3100(26671)', 3784, 1494062201, 1),
(113, 'Mozilla/5.0 (Windows NT 5.1', 2, 1494623229, 1),
(114, 'Deluge 1.3.15', 765, 1494686410, 1),
(115, 'uTorrent/342(109352924)(38876)', 19117, 1494794179, 1),
(116, 'uTorrent 1.5', 1587729, 1495114971, 1),
(117, 'uTorrent/350(111258396)(43804)', 157135, 1495221824, 1),
(118, 'Deluge 1.3.7', 128, 1495967919, 1),
(119, 'uTorrent/349(110340061)(42973)', 459, 1496771332, 1),
(120, 'uTorrent/2200(24683)', 3, 1496812429, 1),
(121, 'Deluge 1.3.13', 165, 1497168135, 1),
(122, 'qBittorrent/3.3.13', 16, 1497215177, 1),
(123, 'uTorrent/3000(25570)', 84, 1497369259, 1),
(124, 'qBittorrent v3.3.1', 6, 1497546876, 1),
(125, 'uTorrent/3320(30586)', 1623, 1497789296, 1),
(126, 'uTorrent/348(110208592)(42576)', 5, 1498207641, 1),
(127, 'uTorrent/350(111258508)(43916)', 219045, 1498977553, 1),
(128, 'BitTorrent/7100(255961997)(43917)', 49575, 1499672666, 1),
(129, 'uTorrentMac/1870(43796)', 6303, 1500722190, 1),
(130, 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36', 1, 1500734298, 0),
(131, 'Azureus 5.7.4.0', 198, 1501945831, 1),
(132, 'uTorrent/2210(25154)', 2287, 1504270973, 1),
(133, 'qBittorrent v3.3.10', 10697, 1506026689, 1),
(134, 'uTorrent/350(111258682)(44090)', 85868, 1506417661, 1),
(135, 'tTorrent v1.5.11', 41, 1508021022, 1),
(136, 'Azureus 5.6.0.1', 13, 1508150175, 1),
(137, 'libtorrent/1.1.3.0', 72, 1508151287, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `announcedelay`
--

CREATE TABLE IF NOT EXISTS `announcedelay` (
  `peer_id` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `first` int(10) unsigned NOT NULL DEFAULT '0',
  `second` int(10) unsigned NOT NULL DEFAULT '0',
  `quantity` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `attachmentdownloads`
--

CREATE TABLE IF NOT EXISTS `attachmentdownloads` (
`id` int(10) unsigned NOT NULL,
  `fileid` int(10) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL DEFAULT '',
  `userid` int(10) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `downloads` int(10) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `attachments`
--

CREATE TABLE IF NOT EXISTS `attachments` (
`id` int(10) unsigned NOT NULL,
  `topicid` int(10) unsigned NOT NULL DEFAULT '0',
  `postid` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0',
  `owner` int(10) unsigned NOT NULL DEFAULT '0',
  `downloads` int(10) unsigned NOT NULL DEFAULT '0',
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `avps`
--

CREATE TABLE IF NOT EXISTS `avps` (
  `arg` varchar(20) NOT NULL DEFAULT '',
  `value_s` text NOT NULL,
  `value_i` int(11) NOT NULL DEFAULT '0',
  `value_u` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `avps`
--

INSERT INTO `avps` (`arg`, `value_s`, `value_i`, `value_u`) VALUES
('lastcleantime', '', 0, 1511370065),
('seeders', '', 0, 0),
('leechers', '', 0, 0),
('last24', '', 3, 1420598002);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bans`
--

CREATE TABLE IF NOT EXISTS `bans` (
`id` int(10) unsigned NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `addedby` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` varchar(255) NOT NULL DEFAULT '',
  `first` int(11) DEFAULT NULL,
  `last` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `bans`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `betting_bet`
--

CREATE TABLE IF NOT EXISTS `betting_bet` (
  `uid` int(10) NOT NULL DEFAULT '0',
  `gid` int(10) NOT NULL DEFAULT '0',
  `tip` int(1) NOT NULL DEFAULT '0',
  `insert` int(18) NOT NULL DEFAULT '0',
  `closed_gid` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `betting_games`
--

CREATE TABLE IF NOT EXISTS `betting_games` (
`gid` int(10) unsigned NOT NULL,
  `home` varchar(64) NOT NULL DEFAULT '',
  `guest` varchar(64) NOT NULL DEFAULT '',
  `type` enum('1.Bundesliga','2.Bundesliga','Champions League','DFB Pokal','UEFA Cup','Auslaendische Liga','EM 2018') NOT NULL DEFAULT '1.Bundesliga',
  `madeby` varchar(100) NOT NULL DEFAULT '0',
  `time` varchar(10) NOT NULL DEFAULT '',
  `in` varchar(18) NOT NULL DEFAULT '0',
  `out` varchar(10) NOT NULL DEFAULT '0',
  `end` tinyint(1) NOT NULL DEFAULT '0',
  `p_home` int(6) NOT NULL DEFAULT '0',
  `p_guest` int(6) NOT NULL DEFAULT '0',
  `quote1` varchar(5) NOT NULL DEFAULT '',
  `quote2` varchar(5) NOT NULL DEFAULT '',
  `quote0` varchar(5) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `blocks`
--

CREATE TABLE IF NOT EXISTS `blocks` (
`id` int(10) unsigned NOT NULL,
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `blockid` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `blocks`
--

INSERT INTO `blocks` (`id`, `userid`, `blockid`) VALUES
(1, 270, 519);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bonus`
--

CREATE TABLE IF NOT EXISTS `bonus` (
`id` int(5) NOT NULL,
  `bonusname` varchar(50) NOT NULL DEFAULT '',
  `points` decimal(10,1) NOT NULL DEFAULT '0.0',
  `description` text NOT NULL,
  `art` varchar(10) NOT NULL DEFAULT 'traffic',
  `menge` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `bonus`
--

INSERT INTO `bonus` (`id`, `bonusname`, `points`, `description`, `art`, `menge`) VALUES
(1, '1 GB Upload', 1000.0, '', 'traffic', 1073741824),
(2, '2.5 GB Upload', 2000.0, '', 'traffic', 2684354560),
(3, '5 GB Upload', 4500.0, '', 'traffic', 5368709120),
(5, '300 GB Upload', 25200.0, '', 'traffic', 312212254720),
(4, '125 GB Upload', 13999.0, '', 'traffic', 134217728000),
(6, '500 GB Upload', 39999.0, '', 'traffic', 568435456000),
(7, '1 TB Upload', 99999.0, '', 'traffic', 1068435456000),
(8, 'Rang: ', 900000.0, 'VIP', 'vip', 0),
(9, '1 Invite', 100000.0, '', 'invite', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bootstrap_design`
--

CREATE TABLE IF NOT EXISTS `bootstrap_design` (
`id` int(10) unsigned NOT NULL,
  `uri` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(64) NOT NULL DEFAULT '',
  `default` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `bootstrap_design`
--

INSERT INTO `bootstrap_design` (`id`, `uri`, `name`, `default`) VALUES
(1, 'x264_acp_v4', 'Ajax UI', 'yes');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(30) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `image` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `std` enum('J','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `stylesheet` varchar(30) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type` int(5) NOT NULL DEFAULT '1',
  `haupt` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `categories`
--

INSERT INTO `categories` (`id`, `name`, `image`, `std`, `stylesheet`, `type`, `haupt`) VALUES
(4, 'PC', 'games.png', 'N', '', 0, 83),
(88, 'XXX', 'xxx-pack.png', 'N', '', 2, 86),
(14, 'Mp3', 'mp3.png', 'N', '', 0, 69),
(16, 'Packs', 'serien-pack.png', 'N', '', 0, 76),
(17, 'PCISO', 'appz-iso.png', 'N', '', 0, 68),
(18, 'Others', 'appz-sonstige.png', 'N', '', 0, 68),
(19, 'Ebooks', 'misc.png', 'N', '', 0, 86),
(23, 'WWE', 'wwe.png', 'N', '', 0, 73),
(64, 'Doku', 'doku.png', 'J', '', 0, 76),
(47, 'Bluray', 'bluray.png', 'N', '', 0, 66),
(48, '720p', '720.png', 'N', '', 0, 66),
(49, '1080p', '1080.png', 'N', '', 0, 66),
(36, 'Hörbuch', 'musik-hoerbuch.png', 'N', '', 0, 69),
(28, 'Windows', 'appz-win.png', 'N', '', 0, 68),
(11, 'DVD-R', 'dvdr.png', 'N', '', 0, 66),
(60, 'HDTV', 'hdtv.png', 'N', '', 0, 66),
(62, 'SD', 'x264.png', 'N', '', 0, 66),
(66, 'Movies', '', 'N', '', 1, 0),
(71, 'Soundtracks', 'mp3.png', 'N', '', 2, 69),
(70, 'Flac', 'mp3.png', 'N', '', 2, 69),
(69, 'Musik', '', 'N', '', 1, 0),
(68, 'Apps', '', 'N', '', 1, 0),
(72, 'Packs', 'mp3.png', 'N', '', 2, 69),
(73, 'Sport', '', 'N', '', 1, 0),
(74, 'Fu&szlig;ball', '', 'N', '', 2, 73),
(75, 'Formel 1', '', 'N', '', 2, 73),
(76, 'Serien', '', 'N', '', 1, 0),
(77, 'SD', '', 'N', '', 2, 76),
(78, '720P', '', 'N', '', 2, 76),
(79, '1080P', '', 'N', '', 2, 76),
(80, 'Bluray', '', 'N', '', 2, 76),
(82, 'DVD-R', '', 'N', '', 2, 76),
(83, 'Games', '', 'N', '', 1, 0),
(84, 'PS3/PS4', '', 'N', '', 2, 83),
(85, 'Xbox-360', '', 'N', '', 2, 83),
(86, 'Misc', '', 'N', '', 1, 0),
(87, 'Anime', '', 'N', '', 2, 86);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cleanup`
--

CREATE TABLE IF NOT EXISTS `cleanup` (
  `switch` tinyint(1) NOT NULL DEFAULT '1',
  `id` tinyint(4) NOT NULL,
  `nclean` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `cleanup`
--

INSERT INTO `cleanup` (`switch`, `id`, `nclean`) VALUES
(1, 0, '2017-11-22 18:31:05');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
`id` int(10) unsigned NOT NULL,
  `user` int(10) unsigned NOT NULL DEFAULT '0',
  `torrent` int(10) unsigned NOT NULL DEFAULT '0',
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `text` text NOT NULL,
  `ori_text` text NOT NULL,
  `editedby` int(10) unsigned NOT NULL DEFAULT '0',
  `editedat` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `completed`
--

CREATE TABLE IF NOT EXISTS `completed` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `torrent_id` int(11) NOT NULL DEFAULT '0',
  `torrent_name` varchar(255) NOT NULL DEFAULT '',
  `torrent_category` int(10) NOT NULL DEFAULT '0',
  `complete_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `config`
--

CREATE TABLE IF NOT EXISTS `config` (
`id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `wert` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `descr` text NOT NULL,
  `ordernum` int(11) DEFAULT '0',
  `bereich` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=176 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `config`
--

INSERT INTO `config` (`id`, `name`, `wert`, `title`, `descr`, `ordernum`, `bereich`) VALUES
(8, 'MAX_USERS', '438', 'Max. Useranzahl', 'Gibt an wieviele User max. auf dieser Seite registriert sein können. Bei überschreitung dieser Marke ist keine Registration mehr möglich bis wieder Plätze frei werden', 0, 'Globale Settings'),
(9, 'SITENAME', 'European Gamer Community', 'Seiten Name', 'Repräsentiert den Namen der Seite an div. Orten wie zb. im Browsertab u.v.m.', 0, 'Globale Settings'),
(11, 'ANNOUNCE_INTERVAL', '60 * 20', 'Announce Updateintervall', 'Diese Option gibt einen Empfehlungswert für Reannounces an, also den Zeitraum, nach dem Clients einen erneuten Announce-Aufruf machen sollen. Leider beachten nur wenige Clients diese Vorgabe, und haben ein festes oder vom Benutzer definierbares Intervall. Aus diesem Grunde sollte die Zeit nicht weniger als 20 Minuten (1200 Sekunden) betragen, da sonst Benutzer von Clients mit längerem festen Intervall dauernd aus der Peerliste entfernt werden.', 0, 'Tracker Settings'),
(12, 'MINVOTES', '1', 'Min. Votes', 'Legt fest, wie viele Bewertungen ein Torrent bereits haben muss, damit die Wertung angezeigt wird. Standart: -> 1 <-', 0, 'Site Settings'),
(13, 'CLIENT_AUTH', 'CLIENT_AUTH_PASSKEY', 'Benutzeridentifizierung der Announce', 'Legt die Art der Benutzeridentifizierung bei Announce-Aufrufen fest. CLIENT_AUTH_IP ist die alte Methode, die einen Benutzer anhand der IP identifiziert, die er beim Aufruf der Torrent-Seite hatte. Diese Methode hat den Nachteil, dass nur ein Benutzer pro IP den Tracker nutzen kann. CLIENT_AUTH_PASSKEY ist daher die neue, bevorzugte Methode, bei der in der Announce-URL ein eindeutiger Schlüssel übergeben wird, der einem Benutzer zugeordnet ist. Diese Methode kann jedoch mit einigen Clients zu Problemen führen, falls diese die Announce-URL nicht korrekt aufbauen. Standart: -> CLIENT_AUTH_PASSKEY <-', 0, 'Tracker Settings'),
(14, 'PASSKEY_SOURCE', 'PASSKEY_USE_PARAM', 'Passkey Quelle', 'Gibt die Quelle für den Passkey an. Diese Option hängt eng mit der Einstellung PASSKEY_ANNOUNCE_URL zusammen, da sie vorgibt, ob der Passkey aus einem zusätzlichen Parameter >passkey< oder aus der Subdomain ausgelesen wird. Da die Subdomain-Variante jedoch nur selten praktikabel ist, sollte diese Option auf PASSKEY_USE_PARAM stehen bleiben. Standart: -> PASSKEY_USE_PARAM <-', 0, 'Tracker Settings'),
(15, 'DOWNLOAD_METHOD', 'DOWNLOAD_ATTACHMENT', 'Download Methode', 'Definiert die Download-Methode für Torrent-Dateien. Der Tracker bietet zwei Möglichkeiten an, eine Torrent-Datei herunterzuladen. Bei der Attachment-Methode wird eine spezielle Kombination von HTTP-Headern benutzt, um dem Browser mitzuteilen, dass die Daten wie ein eMail-Attachment behandelt werden sollen. Dies ermöglicht es, einen Dateinamen anzugeben, der nicht dem des aufgerufenen Scripts entspricht. Jedoch existieren einige Browser, die mit mit dieser Methode Probleme haben. Aus diesem Grund kann über die Option DOWNLOAD_REWRITE im Zusammenspiel mit einem korrekt konfigurierten Apache-Modul >mod_rewrite< eine URL simuliert werden, die dem Browser vortäuscht, tatsächlich eine .torrent-Datei herunterzuladen. Da die Konfiguration von mod_rewrite aber oft problematisch ist, sollte die Attachment-Methode benutzt werden. Standart: > DOWNLOAD_ATTACHMENT <', 0, 'Tracker Settings'),
(16, 'DYNAMIC_RSS', 'TRUE', 'Dyn. Rss Feeds (True/False)', 'Schaltet, ob Dynamisches Rss erlaubt ist, oder nicht.', 0, 'Globale Settings'),
(17, 'MAX_UPLOAD_FILESIZE', '1048576', 'Maximale Filegröße', 'Maximale Größe einer Datei in Bytes, die in den BitBucket hochgeladen werden darf.', 0, 'Upload und Bitbucket'),
(18, 'MAX_BITBUCKET_SIZE_USER', '1048576', 'BitBucket Größe User', 'Maximale Größe des BitBuckets für einen normalen Benutzer in Bytes (Ränge unterhalb Uploader). Standart: > 1024 * 1024 <', 40, 'Upload und Bitbucket'),
(19, 'MAX_BITBUCKET_SIZE_UPLOADER', '5242880', 'BitBucket Größe Uploader', 'Maximale Größe des BitBuckets für Uploader oder höher in Bytes. Standart: > 5 * 1024 * 1024 <', 30, 'Upload und Bitbucket'),
(20, 'BROWSE_CATS_PER_ROW', '5', 'Kategorien pro Zeile', 'Legt fest, wie viele Kategorien in der Torrentübersicht pro Zeile angezeigt werden. Bei langen Kategorienamen kann der Wert reduziert werden, um Zeilenumbrüche zu vermeiden. Standart: > 5 < ', 0, 'Site Settings'),
(21, 'ONLY_LEECHERS_WAIT', 'FALSE', 'Wartezeit Leecher', 'Legt fest, ob Wartezeiten nur gelten, wenn der Benutzer den Torrent noch nicht komplett hat. Ist diese Option auf Aktiviert gesetzt, können Benutzer den Torrent starten, wenn sie diesen fertig haben, bei Deaktiviert ist das nicht möglich. Beachte aber, dass es möglich ist, den Torrent dennoch zu leechen, sollte diese Option auf Aktiviert gesetzt sein! Standart: > Deaktiviert <', 0, 'Tracker Settings'),
(22, 'NOWAITTIME_ONLYSEEDS', 'FALSE', 'Wartezeit Seeder', 'Wenn diese Option auf Aktiviert gesetzt wird, ist es auch bei Torrents, für die die Wartezeit explizit aufgehoben wurde, nicht möglich, zu leechen, sofern man noch eine Wartezeit für diesen Torrent hätte. Diese Option wird in der Regel immer auf Deaktiviert stehen, ansonsten gilt auch hier, dass es dennoch möglich ist, zu cheaten, wenn diese auf Aktiviert gestellt wird. Standart: > Deaktiviert <', 0, 'Tracker Settings'),
(25, 'MAX_PASSKEY_IPS', '5', 'Ips pro passkey', 'Legt fest, wie viele verschiedene IPs ein Benutzer gleichzeitig nutzen darf. Zu den IPs zählen sowohl Seitenbesucher als auch aktive Torrents (Peer-IPs). Ist das Limit bereits erreicht, wird dem Benutzer der Zugang zur Seite verwehrt. Diese Option dient dazu, das PassKey-Sharing zu vermeiden. Standart: > 5 <', 0, 'Tracker Settings'),
(26, 'RATIOFAKER_THRESH', '1024 * 1024', 'Ratiofaker Erkennung', 'Legt fest, ab welcher Übertragungsrate ein Ratiofaker-Eintrag im Benutzerprofil erstellt wird. Bei Trackern, die kein Speedlimit haben, sollte dieser Wert auf ca. 5 MB pro Sekunde gesetzt werden. Ratiofaker-Tools haben normalerweise Uploadraten im GB/s-Bereich.', 0, 'Tracker Settings'),
(28, 'MAX_DEAD_TORRENT_TIME', '2', 'Max. Torrent Deadtime', 'Gibt an wielange ein Torrent ohne Seeder weiterexistieren kann (in Tagen), bevor er automatisch vom System gelöscht wird.', 0, 'Tracker Settings'),
(29, 'MAX_TORRENT_TTL', '28', 'Torrent Lebenszeit (TTL)(Tage)', 'Legt fest, wie lange ein Torrent >lebt< (Time To Live). ein Torrent wird als >lebendig< angesehen, solange er nicht als Tot markiert wurde, und die mit dieser Option festgelegte Zeit nicht abgelaufen ist. Solange ein Torrent also noch Peers hat, wird er nicht gelöscht. Standart > 28 <', 0, 'Tracker Settings'),
(30, 'SIGNUP_TIMEOUT', '48', 'Anmeldefrist (in h)', 'Gibt an wielange ein User Zeit hat, auf die Bestätigungs E-mail zu antworten, bis der Account wieder ungültig wird.', 0, 'Globale Settings'),
(36, 'TORRENT_DIR', '/_x264_/torrents/', 'Torrent Ordner', 'Gibt den Ordner an, in dem alle hochgeladenen .torrent-Dateien abgelegt werden. Der Webserver MUSS Schreibzugriff auf diesen Ordner haben! Standart: > torrents <', 0, 'Folder Settings'),
(37, 'BITBUCKET_DIR', '/_x264_/bitbucket/', 'Bitbucket Ordner', 'Dieser Ordner enthält alle BitBucket-Uploads, NFO-bilder sowie die Torrent-Bilder. Dieser Ordner MUSS ein Unterordner des Tracker-Roots sein, und MUSS öffentlich lesbar sein (via Browser). Ebenfalls MUSS der Webserver auf diesen Ordner Schreibzugriff haben. Ein Referrer-Check für diesen Ordner z.B. via .htaccess/mod_rewrite ist empfehlenswert, um Hotlinking zu erschweren. Standart: > bitbucket <', 0, 'Folder Settings'),
(38, 'PIC_BASE_URL', 'pic/', 'Grafiken Verzeichnis', 'Gibt die URL an, unter der alle festen Interface-Bilder gespeichert sind z.B. Styles, Smilies, ... Die URL MUSS einen abschließenden Slash enthalten! Standart: > pic/ <', 0, 'Folder Settings'),
(39, 'PORTAL_LINK', 'forums.php', 'Forumverzeichnis', 'Gibt die URL an, mittels derer das Tracker-Portal erreichbar ist. Ist diese Option leer, wird der Portal-Link nicht im Menü angezeigt. Standart: > board/ <', 0, 'Folder Settings'),
(40, 'ANNOUNCE_URLS1', 'https://xxxx/announce.php', 'Announce URL', 'Dieses Feld enthält alle für diesen Tracker akzeptierten Announce-URLs. Zwar ist die Angabe bei Verwendung von Passkeys überflüssig, da die Announce-URL im Torrent beim Download ersetzt wird, aber die URL wird dennoch geprüft. Der erste Eintrag in diesem Array wird auf der Upload-Seite als Announce-URL angezeigt.', 0, 'Tracker Settings'),
(41, 'ANNOUNCE_URLS', 'https://xxxx/announce.php', 'Announce URL', 'Dieses Feld enthält alle für diesen Tracker akzeptierten Announce-URLs. Zwar ist die Angabe bei Verwendung von Passkeys überflüssig, da die Announce-URL im Torrent beim Download ersetzt wird, aber die URL wird dennoch geprüft. Der erste Eintrag in diesem Array wird auf der Upload-Seite als Announce-URL angezeigt.', 0, 'Tracker Settings'),
(42, 'PASSKEY_ANNOUNCE_URL', 'https://xxxx/announce.php?passkey={KEY}', 'Announce URL mit Platzhalter', 'Announce URL mit Platzhalter.', 0, 'Tracker Settings'),
(111, 'SHORTTORRENT', '[EGC]', 'SHORTTORRENT', 'SHORTTORRENT', 0, 'Torrents Settings'),
(112, 'DEFAULTBASEURL', 'https://xxxx', 'DEFAULTBASEURL', 'DEFAULTBASEURL', 0, 'Tracker Settings'),
(113, 'TFILES_TEXT', '~OnlyUpload~', 'Torrent Files Text System', 'Torrent Files Text System', 0, 'Torrents Settings'),
(44, 'TRACKERDOMAINS', '', 'Trackerdomains 1', 'Dieses Feld enthält eine Liste aller Domains, unter denen der Tracker erreichbar ist. Dieses Feld wird vom Redirector-Script verwendet, um zwischen lokalen und externen Links zu unterscheiden. Da dies keine URL ist, darf kein http:// vorangestellt, und kein abschließender Slash (/) angehängt werden!', 0, 'Tracker Settings'),
(45, 'TRACKERDOMAINS1', '', 'Trackerdomains 2', 'Dieses Feld enthält eine Liste aller Domains, unter denen der Tracker erreichbar ist. Dieses Feld wird vom Redirector-Script verwendet, um zwischen lokalen und externen Links zu unterscheiden. Da dies keine URL ist, darf kein http:// vorangestellt, und kein abschließender Slash (/) angehängt werden!', 0, 'Tracker Settings'),
(46, 'TRACKERDOMAINS2', '', 'Trackerdomains 3', 'Dieses Feld enthält eine Liste aller Domains, unter denen der Tracker erreichbar ist. Dieses Feld wird vom Redirector-Script verwendet, um zwischen lokalen und externen Links zu unterscheiden. Da dies keine URL ist, darf kein http:// vorangestellt, und kein abschließender Slash (/) angehängt werden!', 0, 'Tracker Settings'),
(47, 'TRACKERDOMAINS3', '', 'Trackerdomains 4', 'Dieses Feld enthält eine Liste aller Domains, unter denen der Tracker erreichbar ist. Dieses Feld wird vom Redirector-Script verwendet, um zwischen lokalen und externen Links zu unterscheiden. Da dies keine URL ist, darf kein http:// vorangestellt, und kein abschließender Slash (/) angehängt werden!', 0, 'Tracker Settings'),
(48, 'SITEEMAIL', 'noreply@xxxx', 'Administrator Email', 'EMail-Adresse des Teams oder des Besitzers! Alle EMails z.B. Registrierungsbenachrichtigungen haben als Absender diese Adresse.', 0, 'Site Settings'),
(64, 'SITE_ONLINE', '1', 'Seite Aktiv (Ja = 1/Nein = 0)', 'Gibt an ob die Seite aktiviert ist.\r\nAchtung! Bei 0 ist diese Konfigurationsoberfläche nicht mehr verfügbar!', 0, 'Globale Settings'),
(63, 'MEMBERSONLY', 'TRUE', 'Nur Angemeldete User', 'Einstellung ob Nur angemeldete User diese Seite Nutzen können.\r\nMomentan wird keine andere einstellung als true unterstützt.', 0, 'Globale Settings'),
(65, 'proofcodeon', 'yes', 'Captcha einschalten?', 'Mit dieser Einstellung (true/false) wird das Captcha an und ausgeschalten', 0, 'Globale Settings'),
(66, 'emailvalidation', 'false', 'Email Bestätigung', 'Mit dieser einstellung wird festgelegt ob Neuregistrierte erst eine Email bestätigen müssen bevor sie freigeschalten werden (true/false)', 0, 'Globale Settings'),
(67, 'EMAIL_BADWORDS_CHECKING', 'true', 'Badword Check bei Emails', 'Legt fest, ob die Email bei der Registierung auf evtl Spammail getestet werden soll. (true/false)', 0, 'Globale Settings'),
(68, 'loginreturnto', 'index.php', 'Nach Login auf die Seite:', 'Seite auf die der User nach dem Login geleitet werden soll.', 0, 'Globale Settings'),
(69, 'SMTP_MAIL', '', 'Smtp Administrator Email', 'Versende Account der SMTP Emails', 50, 'SMTP Mail Settings'),
(70, 'SMTP_USERID', '', 'Smtp User ID', 'ID des Smtp User Accounts.\r\nBei Zweifeln beim Provider nachfragen.', 40, 'SMTP Mail Settings'),
(71, 'SMTP_PASS', '', 'Smtp User Passwort', 'Passwort zum connecten zum Smtp Account', 30, 'SMTP Mail Settings'),
(72, 'SMTP_MAILSERVER', '', 'Smtp Mailserver', 'Mailserver des Postausgangs für SMTP. Bei Zweifeln beim Provider fragen.', 20, 'SMTP Mail Settings'),
(73, 'SMTP_PORT', '25', 'Smtp Port', 'Smtp-port beim Provider.\r\nStandardmässig fast überall Port 25.', 10, 'SMTP Mail Settings'),
(74, 'X264COPYRIGHT', 'Copyright © 2017 European Gamer Community. All rights reserved.', 'D€ Source Copyright', 'Html zur Anzeige der Seite im Footer', 0, 'Site Settings'),
(79, 'SECIRITYTACTICS_NICK', 'security', 'Security Tactics Nickname', 'Security Tactics Nickname', 1, 'Security System'),
(75, 'X264VERSION', '1.6', 'D€ Source Version', 'D€ Version', 0, 'Site Settings'),
(77, 'MEMBERS_PUBLIC', 'no', 'Aktive Mitglieder öffentlich', 'Ob Aktive Mitglieder öffentlich angezeigt werden sollen. (yes/no)', 0, 'Site Settings'),
(76, 'MEMBERS_NEWS_PUBLIC', 'no', 'News Öffentlich? (yes/no)', 'Ob die News für unangemeldete einsehbar sind.', 0, 'Site Settings'),
(80, 'SECIRITYTACTICS_PASSWORD', 'egc2k17', 'Security Tactics Passwort', 'Security Tactics Passwort', 1, 'Security System'),
(81, 'TEMPLATES_SYSTEM', 'templates/', 'System Templates', 'Seiten System Templates', 0, 'Folder Settings'),
(82, 'SALTING_REGISTER', '394fa96945f5ab6806655868bbabcd53dfdd284ef7d9f4a8a0aa0e3e5b5d98c3', 'Salting Register Code', 'Salting Register Code', 1, 'Security System'),
(83, 'SALTING_REGISTER_ACTIVE', 'Online', 'Salting Register Online', 'Header Salting Information', 1, 'Security System'),
(84, 'PROFILE_CHANGE', 'false', 'Profil bearbeiten', 'Profil bearbeiten verwalten', 0, 'Tracker Services'),
(85, 'TORRENT_UPLOAD_OFF', '1', 'Torrent Upload', 'Torrent Upload verwalten', 0, 'Tracker Services'),
(87, 'RADIO_IP', '173.212.214.94', 'Radio IP', 'Radio IP', 0, 'Shoutcast Settings'),
(88, 'RADIO_PORT', '8000', 'Radio Port', 'Radio Port', 0, 'Shoutcast Settings'),
(89, 'RADIO_PASSWORD', '4711DJ', 'Radio Passwort', 'Radio Passwort', 0, 'Shoutcast Settings'),
(102, 'GU_UPLOAD_BONUS', '5368709120', 'Gast Upload Bonus', 'Gast Upload Bonus', 0, 'Torrents Settings'),
(104, 'DESIGN_PATTERN', 'design/', 'Design Folder', 'Design Folder', 0, 'Folder Settings'),
(105, 'CATEGORY_PATTERN', 'category/', 'Category Folder', 'CATEGORY FOLDER', 0, 'Folder Settings'),
(106, 'CLEANUP_SYSTEM', '1', 'Cleanup System', 'Cleanup System ein und ausschalten.', 0, 'Tracker Services'),
(107, 'TORRENT_POSTERS', '/_x264_/torrentpics/', 'Torrent Posters', '/uploading/torrents/', 0, 'Folder Settings'),
(108, 'TF_DOWNLOAD', '1', 'Torrent Download', 'Deaktevieren des Torrent Downloads...', 0, 'Tracker Services'),
(109, 'FREE_SL_SYSTEM', '0', 'Free S&L System', 'Ein und ausschalten das Free S&L System.', 0, 'Tracker Services'),
(110, 'ANNOUNCE_URLS', 'https://xxxx/announce.php', 'ANNOUNCE_URLS', 'ANNOUNCE_URLS', 0, 'Tracker Settings'),
(114, 'FORUM_ONLINE', '1', 'Forum Online', 'FORUM_ONLINE', 0, 'Tracker Services'),
(119, 'SECURITY_TACTICS_SYSTEM_ONLINE', 'Online', 'Security Tactics System Online', 'Security Tactics System Online', 0, 'Security System'),
(120, 'IMG_HOST', '1', 'Img Host System V2', 'Ein und ausschalten', 0, 'Tracker Services'),
(121, 'TF_RL_01', 'TVP', 'Release Group Name', 'Release Group', 0, 'Release Groups'),
(122, 'TF_RL_02', 'ENCOUNTERS', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(123, 'TF_RL_03', 'ACED', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(124, 'TF_RL_04', 'ETM', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(125, 'TF_RL_05', 'VideoStar', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(126, 'TF_RL_06', 'XF', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(127, 'TF_RL_07', 'MORTAL', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(128, 'TF_RL_08', 'CONTRiBUTiON', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(129, 'TF_RL_09', 'WOMBAT', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(130, 'TF_RL_10', 'iFPD', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(131, 'TF_RL_11', 'RELiABLE', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(132, 'TF_RL_12', 'FRACTAL', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(133, 'TF_RL_13', 'GOREHOUNDS', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(134, 'TF_RL_14', 'PsO', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(135, 'TF_RL_15', 'wAx', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(136, 'TF_RL_16', 'PITY', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(137, 'TF_RL_17', 'TALiON', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(138, 'TF_RL_18', 'RELOADED', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(139, 'TF_RL_19', 'SOF', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(140, 'TF_RL_20', 'CRiSP', 'Release Group Name', 'Release Group Name', 0, 'Release Groups'),
(141, 'RESEED_DIFF', '48', 'Reseed System', 'Wieviel Stunden einstellen.', 0, 'Torrents Settings'),
(142, 'TFDL_SEED_BONUS', '2.0', 'Torrent Download Seed Bonus', 'Torrent Download Seed Bonus', 0, 'Torrents Settings'),
(143, 'SECIRITYTACTICS_MSG1', '1178', 'Security Tactics MSG ID 1', 'Security Tactics MSG ID 1', 0, 'Security System'),
(144, 'SECIRITYTACTICS_MSG2', '711', 'Security Tactics MSG ID 2', 'Security Tactics MSG ID 2', 0, 'Security System'),
(148, 'ADMIN_BOOTSTRAP_PATTERN', 'admin/bootstrap/', 'Admin Bootstrap Design', 'Admin Bootstrap Design Folder', 0, 'Folder Settings'),
(147, 'SB_BOT_ENGINE', 'on', 'Shoutbox Bot Engine', 'Shoutbox Bot Engine', 1, 'Tracker Services'),
(149, 'X264_STAFFACP_VERSION', '4.5', 'Staff ACP Version', 'Staff ACP Version', 1, 'Staff ACP'),
(150, 'RADIO_ONLINE', '1', 'Radio Online', 'RADIO_ONLINE', 1, 'Shoutcast Settings'),
(165, 'RADIO_TIMEOUT', '2', 'Radio Timeout', '', 0, 'Shoutcast Settings'),
(151, 'RADIO_ADMIN_PASSWORD', 'pcstaff2k17', 'Radio Admin Passwort', '', 0, 'Shoutcast Settings'),
(161, 'IMDB_DATA', 'cloud-data/', 'IMDB Folder', '', 0, 'Folder Settings'),
(153, 'LAST_EAST', '30', '', '', 0, 'Ostern'),
(154, 'OSTE_AKTIV', '0', 'Ostern Online', '', 0, 'Ostern'),
(159, 'TS3_ADMIN', 'tracker', 'TS3 Admin', '', 0, 'Teamspeak 3'),
(160, 'TS3_PW', 'PC2016', 'TS3 PW', '', 0, 'Teamspeak 3'),
(158, 'TS3_IP', 'ts3.xxxx', 'IP', '', 0, 'Teamspeak 3'),
(162, 'IMDB_DETAILS', '1', 'IMDB Details', '', 0, 'Tracker Services'),
(163, 'RADIO_USER', 'admin', 'Radio User', '', 0, 'Shoutcast Settings'),
(164, 'TS3_PORT', '9987', 'Port', '', 0, 'Teamspeak 3'),
(166, 'SITENAME_LOGO', ' fa-gamepad', 'Sitename Logo', '', 0, 'Globale Settings'),
(167, 'INVITES', '0', 'Invite System', '', 0, 'Invite Settings'),
(168, 'INV_MAX_USERS', '0', 'Invite Max. Users', '', 0, 'Invite Settings'),
(169, 'INV_MAX_INVITES', '0', 'Invite Max. Users Inv', '', 0, 'Invite Settings'),
(170, 'TF_RL_21', 'aWake', 'Release Group Name', '', 0, 'Release Groups'),
(171, 'TF_RL_22', 'SPECTRE', 'Release Group Name', '', 0, 'Release Groups'),
(172, 'TF_RL_23', 'DETAiLS', 'Release Group Name', '', 0, 'Release Groups'),
(173, 'TF_RL_24', 'EXQUiSiTE', 'Release Group Name', '', 0, 'Release Groups'),
(174, 'RSS_FEED', '1', 'Public Feeds', '', 0, 'RSS Feeds'),
(175, 'RSS_newest', 'newest', 'Rss Newest', '', 0, 'RSS Feeds');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `flagpic` varchar(50) COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=106 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `countries`
--

INSERT INTO `countries` (`id`, `name`, `flagpic`) VALUES
(1, 'Sweden', 'sweden.gif'),
(2, 'United States of America', 'usa.gif'),
(3, 'Russia', 'russia.gif'),
(4, 'Finland', 'finland.gif'),
(5, 'Canada', 'canada.gif'),
(6, 'France', 'france.gif'),
(7, 'Germany', 'germany.gif'),
(8, 'China', 'china.gif'),
(9, 'Italy', 'italy.gif'),
(10, 'Denmark', 'denmark.gif'),
(11, 'Norway', 'norway.gif'),
(12, 'United Kingdom', 'uk.gif'),
(13, 'Ireland', 'ireland.gif'),
(14, 'Poland', 'poland.gif'),
(15, 'Netherlands', 'netherlands.gif'),
(16, 'Belgium', 'belgium.gif'),
(17, 'Japan', 'japan.gif'),
(18, 'Brazil', 'brazil.gif'),
(19, 'Argentina', 'argentina.gif'),
(20, 'Australia', 'australia.gif'),
(21, 'New Zealand', 'newzealand.gif'),
(23, 'Spain', 'spain.gif'),
(24, 'Portugal', 'portugal.gif'),
(25, 'Mexico', 'mexico.gif'),
(26, 'Singapore', 'singapore.gif'),
(70, 'India', 'india.gif'),
(65, 'Albania', 'albania.gif'),
(29, 'South Africa', 'southafrica.gif'),
(30, 'South Korea', 'southkorea.gif'),
(31, 'Jamaica', 'jamaica.gif'),
(32, 'Luxembourg', 'luxembourg.gif'),
(33, 'Hong Kong', 'hongkong.gif'),
(34, 'Belize', 'belize.gif'),
(35, 'Algeria', 'algeria.gif'),
(36, 'Angola', 'angola.gif'),
(37, 'Austria', 'austria.gif'),
(38, 'Yugoslavia', 'yugoslavia.gif'),
(39, 'Western Samoa', 'westernsamoa.gif'),
(40, 'Malaysia', 'malaysia.gif'),
(41, 'Dominican Republic', 'dominicanrep.gif'),
(42, 'Greece', 'greece.gif'),
(43, 'Guatemala', 'guatemala.gif'),
(44, 'Israel', 'israel.gif'),
(45, 'Pakistan', 'pakistan.gif'),
(46, 'Czech Republic', 'czechrep.gif'),
(47, 'Serbia', 'serbia.gif'),
(48, 'Seychelles', 'seychelles.gif'),
(49, 'Taiwan', 'taiwan.gif'),
(50, 'Puerto Rico', 'puertorico.gif'),
(51, 'Chile', 'chile.gif'),
(52, 'Cuba', 'cuba.gif'),
(53, 'Congo', 'congo.gif'),
(54, 'Afghanistan', 'afghanistan.gif'),
(55, 'Turkey', 'turkey.gif'),
(56, 'Uzbekistan', 'uzbekistan.gif'),
(57, 'Switzerland', 'switzerland.gif'),
(58, 'Kiribati', 'kiribati.gif'),
(59, 'Philippines', 'philippines.gif'),
(60, 'Burkina Faso', 'burkinafaso.gif'),
(61, 'Nigeria', 'nigeria.gif'),
(62, 'Iceland', 'iceland.gif'),
(63, 'Nauru', 'nauru.gif'),
(64, 'Slovenia', 'slovenia.gif'),
(66, 'Turkmenistan', 'turkmenistan.gif'),
(67, 'Bosnia Herzegovina', 'bosniaherzegovina.gif'),
(68, 'Andorra', 'andorra.gif'),
(69, 'Lithuania', 'lithuania.gif'),
(71, 'Netherlands Antilles', 'nethantilles.gif'),
(72, 'Ukraine', 'ukraine.gif'),
(73, 'Venezuela', 'venezuela.gif'),
(74, 'Hungary', 'hungary.gif'),
(75, 'Romania', 'romania.gif'),
(76, 'Vanuatu', 'vanuatu.gif'),
(77, 'Vietnam', 'vietnam.gif'),
(78, 'Trinidad & Tobago', 'trinidadandtobago.gif'),
(79, 'Honduras', 'honduras.gif'),
(80, 'Kyrgyzstan', 'kyrgyzstan.gif'),
(81, 'Ecuador', 'ecuador.gif'),
(82, 'Bahamas', 'bahamas.gif'),
(83, 'Peru', 'peru.gif'),
(84, 'Cambodia', 'cambodia.gif'),
(85, 'Barbados', 'barbados.gif'),
(86, 'Bangladesh', 'bangladesh.gif'),
(87, 'Laos', 'laos.gif'),
(88, 'Uruguay', 'uruguay.gif'),
(89, 'Antigua Barbuda', 'antiguabarbuda.gif'),
(90, 'Paraguay', 'paraguay.gif'),
(93, 'Thailand', 'thailand.gif'),
(92, 'Union of Soviet Socialist Republics', 'ussr.gif'),
(94, 'Senegal', 'senegal.gif'),
(95, 'Togo', 'togo.gif'),
(96, 'North Korea', 'northkorea.gif'),
(97, 'Croatia', 'croatia.gif'),
(98, 'Estonia', 'estonia.gif'),
(99, 'Colombia', 'colombia.gif'),
(100, 'Lebanon', 'lebanon.gif'),
(101, 'Latvia', 'latvia.gif'),
(102, 'Costa Rica', 'costarica.gif'),
(103, 'Egypt', 'egypt.gif'),
(104, 'Bulgaria', 'bulgaria.gif'),
(105, 'Isla de Muerte', 'jollyroger.gif');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `design`
--

CREATE TABLE IF NOT EXISTS `design` (
  `id` int(10) unsigned NOT NULL,
  `uri` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(64) NOT NULL DEFAULT '',
  `default` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `design`
--

INSERT INTO `design` (`id`, `uri`, `name`, `default`) VALUES
(1, 'ex1080_default', 'D€', 'yes');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `downloadtickets`
--

CREATE TABLE IF NOT EXISTS `downloadtickets` (
`id` int(3) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `userid` int(5) NOT NULL,
  `torrentid` int(5) NOT NULL,
  `added` datetime NOT NULL,
  `last_action` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `faq_categories`
--

CREATE TABLE IF NOT EXISTS `faq_categories` (
`id` int(11) NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `short` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `sort` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `faq_categories`
--

INSERT INTO `faq_categories` (`id`, `name`, `short`, `sort`) VALUES
(10, 'FAQs', 'client', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `faq_questions`
--

CREATE TABLE IF NOT EXISTS `faq_questions` (
`id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `question` text COLLATE latin1_general_ci NOT NULL,
  `answer` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `faq_questions`
--

INSERT INTO `faq_questions` (`id`, `category`, `question`, `answer`) VALUES
(33, 10, 'Willkommen bei European Gamer Community!', 'Unsere FAQs sind noch im Aufbau.');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `files`
--

CREATE TABLE IF NOT EXISTS `files` (
`id` int(10) unsigned NOT NULL,
  `torrent` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `forums`
--

CREATE TABLE IF NOT EXISTS `forums` (
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '0',
`id` int(10) unsigned NOT NULL,
  `name` varchar(60) NOT NULL DEFAULT '',
  `description` varchar(200) DEFAULT NULL,
  `minclassread` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `minclasswrite` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `postcount` int(10) unsigned NOT NULL DEFAULT '0',
  `topiccount` int(10) unsigned NOT NULL DEFAULT '0',
  `minclasscreate` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `fid` int(10) unsigned NOT NULL DEFAULT '0',
  `allowpoll` enum('yes','no') NOT NULL DEFAULT 'no',
  `guest` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `forums`
--

INSERT INTO `forums` (`sort`, `id`, `name`, `description`, `minclassread`, `minclasswrite`, `postcount`, `topiccount`, `minclasscreate`, `fid`, `allowpoll`, `guest`) VALUES
(0, 18, 'Kontakt von außen', 'Hier werden automatisch Kontakt Nachrichten von außen hinzugefügt.', 7, 25, 0, 0, 25, 5, 'no', 'yes');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `forum_cats`
--

CREATE TABLE IF NOT EXISTS `forum_cats` (
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '0',
`id` int(10) unsigned NOT NULL,
  `name` varchar(60) NOT NULL,
  `fid` int(10) unsigned NOT NULL,
  `minclassread` tinyint(3) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `forum_cats`
--

INSERT INTO `forum_cats` (`sort`, `id`, `name`, `fid`, `minclassread`) VALUES
(5, 5, 'Kontakt von außen', 5, 25);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `forum_pollanswers`
--

CREATE TABLE IF NOT EXISTS `forum_pollanswers` (
`id` int(10) unsigned NOT NULL,
  `pollid` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `selection` tinyint(3) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `forum_polls`
--

CREATE TABLE IF NOT EXISTS `forum_polls` (
`id` int(10) unsigned NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `question` varchar(255) NOT NULL,
  `option0` varchar(150) NOT NULL,
  `option1` varchar(150) NOT NULL,
  `option2` varchar(150) NOT NULL,
  `option3` varchar(150) NOT NULL,
  `option4` varchar(150) NOT NULL,
  `option5` varchar(150) NOT NULL,
  `option6` varchar(150) NOT NULL,
  `option7` varchar(150) NOT NULL,
  `option8` varchar(150) NOT NULL,
  `option9` varchar(150) NOT NULL,
  `option10` varchar(150) NOT NULL,
  `sort` enum('yes','no') NOT NULL DEFAULT 'yes',
  `topicid` int(10) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
`id` int(10) unsigned NOT NULL,
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `friendid` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `img_host`
--

CREATE TABLE IF NOT EXISTS `img_host` (
`id` int(10) unsigned NOT NULL,
  `users` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `added` int(10) unsigned NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `height` int(10) unsigned NOT NULL,
  `width` int(10) unsigned NOT NULL,
  `gif` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=MyISAM AUTO_INCREMENT=1843 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `invites`
--

CREATE TABLE IF NOT EXISTS `invites` (
`id` int(10) unsigned NOT NULL,
  `inviter` int(10) unsigned NOT NULL DEFAULT '0',
  `inviteid` int(10) NOT NULL DEFAULT '0',
  `invite` varchar(32) NOT NULL DEFAULT '',
  `time_invited` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `confirmed` char(3) NOT NULL DEFAULT 'no',
  `email` varchar(80) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `invites`
--

INSERT INTO `invites` (`id`, `inviter`, `inviteid`, `invite`, `time_invited`, `confirmed`, `email`) VALUES
(2, 827, 0, 'bc2fdb4e6c08af2cedfd770ed54920a9', '2017-05-18 23:10:55', 'no', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `jamescat`
--

CREATE TABLE IF NOT EXISTS `jamescat` (
`id` int(3) NOT NULL,
  `catname` varchar(20) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=153 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `jamescat`
--

INSERT INTO `jamescat` (`id`, `catname`) VALUES
(151, 'bier'),
(2, 'vodka'),
(3, 'time'),
(4, 'uhr'),
(5, 'tabak'),
(6, 'moin'),
(7, 'joint'),
(8, 'hallo'),
(9, 'huhu'),
(10, 'danke'),
(11, 'thx'),
(12, 'hammer'),
(13, 'runde'),
(14, 'feuer'),
(15, 'bye'),
(16, 'cu'),
(17, 'kaffee'),
(18, 'not'),
(19, 'thanks'),
(24, 'heirat'),
(26, 'shock'),
(27, 'nacht'),
(28, 'frech'),
(29, 'weiber'),
(30, 'hunger'),
(31, 'sex'),
(33, 'l&uuml;gen'),
(34, 'wie geht'),
(35, 'party'),
(36, 'beste'),
(38, 'tanzen'),
(47, 'hilfe'),
(40, 'verein'),
(42, 'schluckspecht'),
(44, 's/l'),
(50, 'help'),
(49, 'pausen'),
(51, 'geburtstag'),
(52, 'witz'),
(53, 'brille'),
(55, 'guten tag'),
(57, 'kaffee f&uuml;r alle'),
(58, 'kasten'),
(59, 'guten morgen'),
(60, 'radio'),
(61, 'gn8'),
(62, 'geb'),
(63, 'hundeh&uuml;tte'),
(100, 'hennes'),
(97, 'radio2'),
(70, 'doof'),
(71, 'entf&uuml;hre'),
(73, 'cola'),
(74, 'ich gebastelt'),
(77, 'morgen'),
(98, 'neu torrent'),
(81, 'erntedankfest'),
(82, 'schlagwort'),
(83, 'schlagw&ouml;rter'),
(101, 'termin'),
(85, 'sing'),
(99, 'zufalls torrent'),
(87, 'coffee'),
(88, 'gamler'),
(91, 'tombola'),
(102, 'rwo'),
(103, 'preise'),
(104, 'tippspiel'),
(105, 'oberhausen'),
(106, 'ruhrpott'),
(107, 'kurve'),
(108, 'elferliga'),
(109, 'frosch'),
(110, 'radio power'),
(112, 'rwe'),
(113, 'schalke'),
(114, 'scuril'),
(115, 'sturm'),
(116, 'froh'),
(117, 'weihnachten'),
(118, 'silvester'),
(119, 'alten'),
(120, 'feuerwerk'),
(121, 'hygi'),
(122, 'gamler und hygi'),
(143, 'knolle'),
(124, 'nudels'),
(126, 'drink'),
(129, 'music'),
(139, 'please'),
(131, 'dj nudels'),
(132, 'snatch and leave'),
(133, 'dreamteam'),
(134, 'vergessen'),
(135, 'url'),
(136, 'alkoholiker'),
(137, 'spass'),
(138, 'streamstatus'),
(140, 'sagst'),
(141, 'ostern'),
(144, 'gesetz'),
(145, 'l&auml;uft'),
(146, 'colonia'),
(147, 'kaffee ole'),
(148, 'f1'),
(149, 'hektor'),
(150, 'verheiratet'),
(152, 'ich liebe dich');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `jamestext`
--

CREATE TABLE IF NOT EXISTS `jamestext` (
`id` int(3) NOT NULL,
  `catid` int(3) NOT NULL,
  `text` text,
  `uid` int(3) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `jamestext`
--

INSERT INTO `jamestext` (`id`, `catid`, `text`, `uid`) VALUES
(1, 151, 'Du willst ein Bier? Dann geh dir eins kaufen.', 1),
(2, 87, 'Ich bring dir dein Kaffee nur, wenn du mich lieb hast.', 1),
(3, 10, 'Wof&uuml;r Danke?', 1),
(4, 47, 'Du brauchst Hilfe? Dann nehme mit den Staff kontakt auf.', 1),
(5, 73, 'Im Penny Markt gibt es Cola zu kaufen, dann schwing dich und fahr dort hin.:106:', 1),
(6, 17, 'Na Kaffee Junkie, du bekommst heute kein Kaffee von mir. :106:', 1),
(7, 17, 'Einen moment bitte, der Kaffee kommt sofort.', 1),
(8, 31, 'Was zahlst du denn f&uuml;r die Stunde?', 1),
(9, 31, 'Das ganze kostet dich 50 €, also lass mal r&uuml;ber wachsen.', 1),
(10, 98, 'Leute es gibt wieder was neues zum Herunterladen!', 1),
(11, 57, 'Ich schmeiss mal f&uuml;r alle eine Runde Kaffee im Raum.', 1),
(12, 70, 'Hast du heute schon mal im Spiegel geschaut? :106:', 1),
(13, 30, 'Ich hab auch Hunger....', 1),
(14, 87, 'Kaffee gibt es heute nicht...', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lotto_abonnement`
--

CREATE TABLE IF NOT EXISTS `lotto_abonnement` (
`abo_id` int(10) unsigned NOT NULL,
  `abo_userID` int(10) unsigned NOT NULL DEFAULT '0',
  `abo_aboPackId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `abo_purchaseDate` int(12) NOT NULL DEFAULT '0',
  `abo_length` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `abo_superIntActive` enum('yes','no') NOT NULL DEFAULT 'no',
  `abo_userNumbers` varchar(17) DEFAULT NULL,
  `abo_superInt` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `abo_lastDrawing` int(12) unsigned NOT NULL DEFAULT '0',
  `abo_lastNumberChange` int(12) unsigned NOT NULL DEFAULT '0',
  `abo_infoMessage` enum('yes','no') NOT NULL DEFAULT 'no',
  `abo_aboWonBytes` bigint(20) unsigned NOT NULL DEFAULT '0',
  `abo_aboWonCount` mediumint(8) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COMMENT='Lottery abonnements';

--
-- Daten für Tabelle `lotto_abonnement`
--

INSERT INTO `lotto_abonnement` (`abo_id`, `abo_userID`, `abo_aboPackId`, `abo_purchaseDate`, `abo_length`, `abo_superIntActive`, `abo_userNumbers`, `abo_superInt`, `abo_lastDrawing`, `abo_lastNumberChange`, `abo_infoMessage`, `abo_aboWonBytes`, `abo_aboWonCount`) VALUES
(1, 827, 12, 1489924219, 19, 'yes', '17,37,1,16,4,7', 5, 1509818852, 1490304318, 'yes', 11244816190, 39),
(2, 827, 12, 1489932746, 84, 'yes', NULL, 0, 0, 0, 'no', 0, 0),
(3, 827, 12, 1489932750, 84, 'no', NULL, 0, 0, 0, 'no', 0, 0),
(4, 719, 1, 1489936865, 1, 'yes', NULL, 0, 0, 0, 'no', 0, 0),
(5, 719, 2, 1489936873, 2, 'no', NULL, 0, 0, 0, 'no', 0, 0),
(6, 719, 4, 1489936877, 4, 'no', NULL, 0, 0, 0, 'no', 0, 0),
(7, 711, 12, 1489937345, 14, 'yes', '38,45,16,15,25,12', 8, 1509818852, 1489937408, 'no', 14750290830, 48),
(8, 711, 12, 1489937361, 14, 'yes', '9,32,26,14,27,30', 9, 1509818852, 1489937459, 'no', 10157712998, 42),
(10, 827, 12, 1489944173, 84, 'no', NULL, 0, 0, 0, 'no', 0, 0),
(11, 827, 12, 1489944177, 84, 'yes', NULL, 0, 0, 0, 'no', 0, 0),
(28, 714, 8, 1492278442, 3, 'yes', '23,39,5,34,12,11', 8, 1509818852, 1492278495, 'yes', 15862428195, 30),
(19, 827, 12, 1490121848, 84, 'no', NULL, 0, 0, 0, 'no', 0, 0),
(12, 827, 12, 1489957277, 84, 'no', NULL, 0, 0, 0, 'no', 0, 0),
(13, 827, 12, 1489957281, 84, 'yes', NULL, 0, 0, 0, 'no', 0, 0),
(14, 714, 7, 1489957340, 4, 'yes', '26,19,13,10,48,16', 2, 1509818852, 1498670472, 'yes', 3984588800, 37),
(15, 827, 12, 1490036223, 84, 'no', NULL, 0, 0, 0, 'no', 0, 0),
(16, 827, 12, 1490036226, 84, 'yes', NULL, 0, 0, 0, 'no', 0, 0),
(17, 827, 12, 1490115970, 84, 'no', NULL, 0, 0, 0, 'no', 0, 0),
(18, 827, 12, 1490115974, 84, 'yes', NULL, 0, 0, 0, 'no', 0, 0),
(20, 827, 12, 1490121851, 84, 'yes', NULL, 0, 0, 0, 'no', 0, 0),
(21, 714, 8, 1490172188, 7, 'yes', '46,8,29,40,2,31', 9, 1509818852, 1490172231, 'yes', 17519302305, 34),
(22, 827, 12, 1490304036, 19, 'yes', '8,30,46,10,49,9', 0, 1509818852, 1490304410, 'yes', 6175683571, 28),
(23, 827, 12, 1490304224, 19, 'yes', '12,9,22,33,6,49', 9, 1509818852, 1490304381, 'no', 3932160000, 44),
(24, 712, 12, 1490304262, 19, 'yes', '19,15,20,43,11,34', 5, 1509818852, 1490304393, 'yes', 11026816779, 39),
(25, 712, 12, 1490304553, 19, 'yes', '46,47,44,33,37,9', 1, 1509818852, 1490304576, 'yes', 31517992659, 34),
(26, 865, 12, 1490988944, 21, 'yes', '4,8,11,15,24,27', 7, 1509818852, 1490988972, 'yes', 18984512255, 37),
(27, 714, 7, 1491420810, 4, 'yes', '47,12,24,10,48,29', 2, 1509818852, 1491420847, 'yes', 29930127212, 31),
(29, 714, 7, 1497167161, 4, 'yes', '41,25,35,9,20,22', 9, 1509818852, 1498670533, 'yes', 2044723200, 16),
(30, 941, 1, 1498936932, 0, 'yes', '13,20,9,14,11,48', 5, 1507137921, 1506853362, 'no', 52428800, 1),
(31, 785, 11, 1505929293, 44, 'yes', '46,17,14,13,33,28', 6, 1509818852, 1506789136, 'yes', 262144000, 4),
(32, 820, 12, 1507312550, 75, 'yes', '10,19,22,25,32,30', 4, 1509818852, 1507312579, 'yes', 7625468858, 5),
(33, 820, 12, 1507312616, 75, 'no', '16,21,3,1,33,6', 0, 1509818852, 1507312654, 'yes', 3967775799, 5),
(34, 1077, 12, 1507368292, 75, 'yes', '8,19,10,12,38,48', 4, 1509818852, 1507368424, 'no', 419430400, 5),
(35, 779, 9, 1509280808, 19, 'yes', '13,21,10,30,42,2', 3, 1509818852, 1509280835, 'no', 104857600, 2),
(36, 779, 8, 1509280823, 12, 'yes', '49,11,30,19,40,44', 6, 1509818852, 1509280851, 'no', 157286400, 2),
(37, 779, 12, 1509280907, 82, 'yes', '5,1,48,13,2,6', 4, 1509818852, 1509280941, 'no', 471859200, 3),
(38, 779, 12, 1509280910, 82, 'yes', '18,35,34,31,49,10', 6, 1509818852, 1509280953, 'no', 52428800, 1),
(39, 779, 12, 1509280914, 82, 'yes', '10,37,8,22,25,16', 8, 1509818852, 1509280963, 'no', 104857600, 2),
(40, 779, 12, 1509280918, 82, 'yes', '43,28,40,6,39,5', 7, 1509818852, 1509280974, 'no', 157286400, 2),
(41, 779, 12, 1509280921, 82, 'yes', '6,25,24,3,7,36', 2, 1509818852, 1509280982, 'no', 3967775799, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lotto_aboPacks`
--

CREATE TABLE IF NOT EXISTS `lotto_aboPacks` (
`aboPack_id` int(10) unsigned NOT NULL,
  `aboPack_desc` varchar(25) NOT NULL DEFAULT '',
  `aboPack_lenght` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `aboPack_price` bigint(15) NOT NULL DEFAULT '0',
  `aboPack_priceSuperInt` bigint(15) NOT NULL DEFAULT '0',
  `aboPack_reduce` decimal(3,1) unsigned zerofill NOT NULL DEFAULT '00.0'
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='Lottery Abo Packs';

--
-- Daten für Tabelle `lotto_aboPacks`
--

INSERT INTO `lotto_aboPacks` (`aboPack_id`, `aboPack_desc`, `aboPack_lenght`, `aboPack_price`, `aboPack_priceSuperInt`, `aboPack_reduce`) VALUES
(1, '1 Lottoschein', 1, 157286400, 209715200, 00.0),
(2, '2 Lottoscheine', 2, 314572800, 419430400, 00.0),
(3, '3 Lottoscheine', 3, 471859200, 629145600, 00.0),
(4, '4 Lottoscheine', 4, 629145600, 838860800, 00.0),
(5, '5 Lottoscheine', 5, 786432000, 1048576000, 00.0),
(6, '6 Lottoscheine', 6, 943718400, 1258291200, 00.0),
(7, '7 Lottoscheine', 7, 990904320, 1321205760, 10.0),
(8, '14 Lottoscheine', 14, 1981808640, 2642411520, 12.5),
(9, '21 Lottoscheine', 21, 2972712960, 3963617280, 15.0),
(10, '28 Lottoscheine', 28, 3633315840, 4844421120, 17.5),
(11, '56 Lottoscheine', 56, 7046430720, 9395240960, 20.0),
(12, '84 Lottoscheine', 84, 9909043200, 13212057600, 25.0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lotto_config`
--

CREATE TABLE IF NOT EXISTS `lotto_config` (
  `lottery_name` varchar(20) NOT NULL DEFAULT '6 aus 49',
  `lottery_active` enum('yes','no') NOT NULL DEFAULT 'yes',
  `lottery_withSuperInt` enum('yes','no') NOT NULL DEFAULT 'no',
  `lottery_winHour` tinyint(2) unsigned NOT NULL DEFAULT '20',
  `lottery_days` varchar(13) NOT NULL DEFAULT '0,1,2,3,4,5,6',
  `lottery_jackpot` bigint(20) unsigned NOT NULL DEFAULT '0',
  `lottery_lastNumber` varchar(17) NOT NULL DEFAULT '',
  `lottery_lastSuperInt` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lottery_lastDrawing` int(12) unsigned NOT NULL DEFAULT '0',
  `lottery_lastInfoMessage` int(12) unsigned NOT NULL DEFAULT '0',
  `lottery_drawCount` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lottery_playerWonCount` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lottery_jackpotOutput` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Configs for lottery';

--
-- Daten für Tabelle `lotto_config`
--

INSERT INTO `lotto_config` (`lottery_name`, `lottery_active`, `lottery_withSuperInt`, `lottery_winHour`, `lottery_days`, `lottery_jackpot`, `lottery_lastNumber`, `lottery_lastSuperInt`, `lottery_lastDrawing`, `lottery_lastInfoMessage`, `lottery_drawCount`, `lottery_playerWonCount`, `lottery_jackpotOutput`) VALUES
('6 aus 49', 'yes', 'yes', 19, '3,6', 751612119792, '42,19,6,7,29,32', 6, 1509818852, 1509815250, 71, 483, 193831187728);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lotto_stats`
--

CREATE TABLE IF NOT EXISTS `lotto_stats` (
`stats_id` int(10) unsigned NOT NULL,
  `stats_event` enum('incoming','outgoing','userWin','buyAbo','deleteAbo','newNumbers') NOT NULL DEFAULT 'incoming',
  `stats_userID` int(10) unsigned NOT NULL DEFAULT '0',
  `stats_aboID` int(10) unsigned NOT NULL DEFAULT '0',
  `stats_desc` varchar(200) DEFAULT NULL,
  `stats_insertDate` int(12) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=785 DEFAULT CHARSET=utf8 COMMENT='Lottery Statistic / Logs';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
`id` int(10) NOT NULL,
  `type` set('haupt','unter') NOT NULL DEFAULT 'haupt',
  `name` text NOT NULL,
  `url` text NOT NULL,
  `class` int(11) NOT NULL DEFAULT '1',
  `haupt` int(10) NOT NULL DEFAULT '0',
  `order` int(10) NOT NULL DEFAULT '0',
  `icon` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=183 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `menu`
--

INSERT INTO `menu` (`id`, `type`, `name`, `url`, `class`, `haupt`, `order`, `icon`) VALUES
(108, 'haupt', 'Community', '#', 0, 0, 1, ''),
(109, 'haupt', 'Account', '#', 0, 0, 2, ''),
(161, 'unter', 'Request System', 'requests_system.php', 0, 118, 3, 'fa fa-database'),
(111, 'unter', 'Bearbeiten', 'profile.php', 0, 109, 1, 'fa fa-wrench'),
(112, 'unter', 'FAQ', 'faq.php', 0, 108, 2, 'fa fa-info'),
(113, 'unter', 'Rules', 'rules.php', 0, 108, 3, 'fa fa-info-circle'),
(117, 'unter', 'Meine Torrents', 'mytorrents.php', 0, 109, 4, 'fa fa-film'),
(116, 'unter', 'Imghost System', 'img-host.php', 0, 122, 3, 'fa fa-file-image-o'),
(118, 'haupt', 'Torrents', '#', 0, 0, 3, ''),
(119, 'unter', 'Durchsuchen', 'tfiles.php', 0, 118, 1, 'fa fa-download'),
(120, 'unter', 'Hochladen', 'tfile_add.php', 0, 118, 2, 'fa fa-upload'),
(122, 'haupt', 'Support', '#', 0, 0, 4, ''),
(123, 'unter', 'Scene Begriffe', 'sceneinfo.php', 0, 122, 1, 'fa fa-pie-chart'),
(155, 'unter', 'Seed Bonus Shop', 'seedbonus.php', 0, 109, 9, 'fa fa-usd'),
(125, 'haupt', 'Backend ACP', '#', 7, 0, 6, ''),
(135, 'unter', 'Buddylist', 'friends.php', 0, 109, 6, 'fa fa-female'),
(132, 'unter', 'Members', 'users.php', 25, 108, 5, 'fa icon-people'),
(152, 'unter', 'BT-Clients', 'btclient_info.php', 0, 122, 8, 'fa fa-paw'),
(153, 'unter', 'Mitteilungen', 'messages.php', 0, 109, 8, 'fa fa-envelope-o'),
(140, 'unter', 'Team PM', '/teampm.php', 0, 122, 6, 'fa fa-ticket'),
(179, 'unter', 'Team PMs', 'staffbox.php', 25, 125, 14, 'fa fa-industry'),
(151, 'unter', 'BBCodes', 'tags.php', 0, 122, 7, 'fa fa-bar-chart'),
(157, 'unter', 'Partners', 'partners.php', 1, 108, 6, 'fa fa-users'),
(159, 'unter', 'Mein Profil', 'userdetails.php', 0, 109, 11, 'fa fa-user'),
(164, 'unter', 'Windows 10', 'win10spionage.php', 0, 122, 9, 'fa fa-lightbulb-o'),
(168, 'unter', 'Staff', 'team.php', 5, 108, 9, 'fa fa-building-o'),
(166, 'unter', 'PreDB', 'predb.php', 0, 118, 4, 'fa fa-hdd-o'),
(167, 'unter', 'Partner News', 'p_news.php', 1, 108, 8, 'fa fa-users'),
(169, 'haupt', 'Games', '#', 0, 0, 5, ''),
(170, 'unter', 'Slot Machine', 'slot_machine_tp.php', 0, 169, 1, 'fa fa-gamepad'),
(173, 'unter', 'Dashboard', 'backend_acp.php', 25, 125, 13, 'fa fa-signal'),
(174, 'unter', 'Kino News', 'kinonews.php', 0, 118, 5, 'fa fa-keyboard-o'),
(177, 'unter', 'Lotterie', 'lottery.php', 0, 169, 3, 'fa fa-gamepad'),
(181, 'unter', 'Ausloggen', 'logout.php', 0, 109, 13, 'fa fa-lock'),
(182, 'unter', 'Highlight Torrents', 'tfiles_highlight.php', 0, 118, 6, 'fa fa-align-justify');
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
`id` int(10) unsigned NOT NULL,
  `sender` int(10) unsigned NOT NULL DEFAULT '0',
  `receiver` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_in` int(10) NOT NULL DEFAULT '0',
  `folder_out` int(10) NOT NULL DEFAULT '0',
  `added` datetime DEFAULT NULL,
  `subject` varchar(255) NOT NULL DEFAULT '(Kein Betreff)',
  `msg` text,
  `unread` enum('yes','no') NOT NULL DEFAULT 'yes',
  `poster` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mod_flag` enum('','open','closed') NOT NULL DEFAULT '',
  `save_sender` int(1) unsigned NOT NULL,
  `save_receiver` int(1) unsigned NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `modcomments`
--

CREATE TABLE IF NOT EXISTS `modcomments` (
`id` int(11) NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `moduid` int(10) unsigned NOT NULL DEFAULT '0',
  `txt` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `news`
--

CREATE TABLE IF NOT EXISTS `news` (
`id` int(10) unsigned NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `body` text COLLATE latin1_german1_ci NOT NULL,
  `title` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `userid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Daten für Tabelle `news`
--

INSERT INTO `news` (`id`, `added`, `body`, `title`, `userid`) VALUES
(94, '2017-11-09 20:59:36', 'Wir sind noch im Aufbau, \r\n\r\ndaher haben Sie Verständnis, \r\n\r\ndass unser Design noch nicht zu 100% Perfekt ist.\r\n\r\nMit freundlichen Grüßen\r\n\r\nEuropean Gamer Community', 'Willkommen bei European Gamer Community', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `nowait`
--

CREATE TABLE IF NOT EXISTS `nowait` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `torrent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` enum('pending','granted','rejected') NOT NULL DEFAULT 'pending',
  `grantor` int(10) NOT NULL DEFAULT '0',
  `msg` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `overspeed`
--

CREATE TABLE IF NOT EXISTS `overspeed` (
`id` int(10) unsigned NOT NULL,
  `userid` varchar(255) NOT NULL,
  `torrentid` varchar(255) NOT NULL,
  `done` enum('no','yes') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `partner`
--

CREATE TABLE IF NOT EXISTS `partner` (
`id` int(10) unsigned NOT NULL,
  `titel` varchar(255) DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  `link` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `partner`
--

INSERT INTO `partner` (`id`, `titel`, `banner`, `link`) VALUES
(84, 'Elite-of-Darkness', 'https://elite-of-darkness.de/uploads/site_logo.png', 'https://elite-of-darkness.de/');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `peers`
--

CREATE TABLE IF NOT EXISTS `peers` (
`id` int(10) unsigned NOT NULL,
  `torrent` int(10) unsigned NOT NULL DEFAULT '0',
  `peer_id` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `ip` varchar(256) NOT NULL DEFAULT '',
  `port` smallint(5) unsigned NOT NULL DEFAULT '0',
  `uploaded` bigint(20) unsigned NOT NULL DEFAULT '0',
  `downloaded` bigint(20) unsigned NOT NULL DEFAULT '0',
  `to_go` bigint(20) unsigned NOT NULL DEFAULT '0',
  `seeder` enum('yes','no') NOT NULL DEFAULT 'no',
  `started` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_action` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `connectable` enum('yes','no') NOT NULL DEFAULT 'yes',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `agent` varchar(60) NOT NULL DEFAULT '',
  `finishedat` int(10) unsigned NOT NULL DEFAULT '0',
  `downloadoffset` bigint(20) unsigned NOT NULL DEFAULT '0',
  `uploadoffset` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `pmfolders`
--

CREATE TABLE IF NOT EXISTS `pmfolders` (
`id` int(10) unsigned NOT NULL,
  `parent` int(10) unsigned NOT NULL DEFAULT '0',
  `owner` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) NOT NULL DEFAULT '',
  `sortfield` varchar(64) NOT NULL DEFAULT 'added',
  `sortorder` varchar(4) NOT NULL DEFAULT 'DESC',
  `prunedays` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `pmfolders`
--

INSERT INTO `pmfolders` (`id`, `parent`, `owner`, `name`, `sortfield`, `sortorder`, `prunedays`) VALUES
(1, 0, 1, '__inbox', 'added', 'DESC', 0),
(2, 0, 1, '__outbox', 'added', 'DESC', 0),
(3, 0, 1, '__system', 'added', 'DESC', 0),
(4, 0, 1, '__mod', 'added', 'DESC', 0),
(5, 0, 6, '__inbox', 'added', 'DESC', 0),
(6, 0, 6, '__outbox', 'added', 'DESC', 0),
(7, 0, 6, '__system', 'added', 'DESC', 0),
(8, 0, 6, '__mod', 'added', 'DESC', 0),
(9, 0, 7, '__inbox', 'subject', 'DESC', 0),
(10, 0, 7, '__outbox', 'added', 'DESC', 0),
(11, 0, 7, '__system', 'added', 'DESC', 0),
(12, 0, 7, '__mod', 'added', 'DESC', 0),
(13, 0, 8, '__inbox', 'added', 'DESC', 0),
(14, 0, 8, '__outbox', 'added', 'DESC', 0),
(15, 0, 8, '__system', 'added', 'DESC', 0),
(16, 0, 8, '__mod', 'added', 'DESC', 0),
(17, 0, 3, '__inbox', 'added', 'DESC', 0),
(18, 0, 3, '__outbox', 'added', 'DESC', 0),
(19, 0, 3, '__system', 'added', 'DESC', 0),
(20, 0, 3, '__mod', 'added', 'DESC', 0),
(21, 0, 10, '__inbox', 'added', 'DESC', 0),
(22, 0, 10, '__outbox', 'added', 'DESC', 0),
(23, 0, 10, '__system', 'added', 'DESC', 0),
(24, 0, 10, '__mod', 'added', 'DESC', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `pollsnew`
--

CREATE TABLE IF NOT EXISTS `pollsnew` (
`id` int(11) NOT NULL,
  `frage` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `erstellt` int(15) NOT NULL,
  `antworten1` int(11) NOT NULL DEFAULT '0',
  `antworten2` int(11) NOT NULL DEFAULT '0',
  `antworten3` int(11) NOT NULL DEFAULT '0',
  `antworten4` int(11) NOT NULL DEFAULT '0',
  `antworten5` int(11) NOT NULL DEFAULT '0',
  `antworten6` int(11) NOT NULL DEFAULT '0',
  `antworten7` int(11) NOT NULL DEFAULT '0',
  `antworten8` int(11) NOT NULL DEFAULT '0',
  `antworten9` int(11) NOT NULL DEFAULT '0',
  `antworten10` int(11) NOT NULL DEFAULT '0',
  `antworten11` int(11) NOT NULL DEFAULT '0',
  `antworten12` int(11) NOT NULL DEFAULT '0',
  `antworten13` int(11) NOT NULL DEFAULT '0',
  `antworten14` int(11) NOT NULL DEFAULT '0',
  `antworten15` int(11) NOT NULL DEFAULT '0',
  `antwort1` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort2` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort3` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort4` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort5` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort6` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort7` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort8` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort9` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort10` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort11` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort12` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort13` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort14` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `antwort15` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `dauer` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  `balken` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  `anzantworten` int(3) DEFAULT NULL,
  `maxvotes` int(2) NOT NULL DEFAULT '0',
  `end` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no'
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `pollsnewsettings`
--

CREATE TABLE IF NOT EXISTS `pollsnewsettings` (
  `setting` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `value` varchar(50) COLLATE latin1_general_ci NOT NULL,
`id` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `pollsnewvotes`
--

CREATE TABLE IF NOT EXISTS `pollsnewvotes` (
`id` int(11) NOT NULL,
  `abgestimmt` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `voteid` int(11) DEFAULT NULL,
  `votes` int(3) NOT NULL DEFAULT '0',
  `realvotes` int(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) unsigned NOT NULL,
  `topicid` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `added` datetime DEFAULT NULL,
  `body` text,
  `editedby` int(10) unsigned NOT NULL DEFAULT '0',
  `editedat` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `guestuser` enum('yes','no') NOT NULL DEFAULT 'no',
  `guestname` varchar(40) NOT NULL,
  `guestmail` varchar(80) NOT NULL,
  `answer` enum('yes','no') NOT NULL DEFAULT 'no',
  `bedanko` enum('1','2') DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `postthanks`
--

CREATE TABLE IF NOT EXISTS `postthanks` (
`id` int(11) NOT NULL,
  `topicid` int(11) NOT NULL DEFAULT '0',
  `postid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `privatechat`
--

CREATE TABLE IF NOT EXISTS `privatechat` (
`id` int(3) NOT NULL,
  `added` int(10) NOT NULL,
  `absender` int(3) NOT NULL,
  `empfanger` int(3) NOT NULL,
  `msg` text,
  `unread` enum('yes','no') NOT NULL DEFAULT 'yes'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `p_news`
--

CREATE TABLE IF NOT EXISTS `p_news` (
`id` bigint(255) NOT NULL,
  `datum` datetime NOT NULL,
  `von` varchar(255) NOT NULL,
  `titel` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `tracker` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ratings`
--

CREATE TABLE IF NOT EXISTS `ratings` (
  `torrent` int(10) unsigned NOT NULL DEFAULT '0',
  `user` int(10) unsigned NOT NULL DEFAULT '0',
  `rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rating_video` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `added_video` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `ratings`
--

INSERT INTO `ratings` (`torrent`, `user`, `rating`, `added`, `rating_video`, `added_video`) VALUES
(4, 29, 5, '2015-05-25 18:23:57', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ratiostats`
--

CREATE TABLE IF NOT EXISTS `ratiostats` (
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `timecode` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` enum('daily','hourly') NOT NULL DEFAULT 'hourly',
  `downloaded` bigint(20) unsigned NOT NULL DEFAULT '0',
  `uploaded` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `readposts`
--

CREATE TABLE IF NOT EXISTS `readposts` (
`id` int(10) unsigned NOT NULL,
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `topicid` int(10) unsigned NOT NULL DEFAULT '0',
  `lastpostread` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `requestcomments`
--

CREATE TABLE IF NOT EXISTS `requestcomments` (
`id` int(10) unsigned NOT NULL,
  `comments` text NOT NULL,
  `commentid` int(10) unsigned NOT NULL DEFAULT '0',
  `user` int(10) NOT NULL,
  `datum` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `requests`
--

CREATE TABLE IF NOT EXISTS `requests` (
`id` int(10) unsigned NOT NULL,
  `user` int(10) unsigned NOT NULL DEFAULT '0',
  `kategorie` int(10) unsigned NOT NULL DEFAULT '0',
  `titel` varchar(255) NOT NULL,
  `info` text NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `closed` int(10) unsigned NOT NULL DEFAULT '0',
  `ruser` int(10) NOT NULL DEFAULT '0',
  `closedate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `requests`
--

INSERT INTO `requests` (`id`, `user`, `kategorie`, `titel`, `info`, `added`, `closed`, `ruser`, `closedate`) VALUES
(89, 827, 0, '<font color=red>Suche:&nbsp;</font>Test', 'bb b', '2017-06-22 21:16:34', 0, 0, '0000-00-00 00:00:00'),
(106, 941, 76, '<font color=red>Suche:&nbsp;</font>Fear the Walking  Deadline S03 bis E16 in Deutsch', 'Serie Staffel 3 bis zur aktuellsten Folge 16. Danke!', '2017-10-16 22:04:34', 37123, 711, '2017-10-17 16:10:34'),
(101, 1040, 66, '<font color=red>Suche:&nbsp;</font>Evil/Ondskan/Fausrecht', 'W&uuml;rde mich freuen wenn Jemand den Film Ondskan, auch unter den Namen Evil oder Fausrecht erschienen uppen k&ouml;nnte in XVID oder H264  \r\n\r\nhttp://www.imdb.com/title/tt0338309/', '2017-09-18 20:25:20', 0, 0, '0000-00-00 00:00:00'),
(102, 751, 76, '<font color=red>Suche:&nbsp;</font>Bad.Cop.kriminell.gut.S01E02.GERMAN.HDTV.x264-ACED', 'Bitte den 2. Teil', '2017-09-25 18:50:18', 35788, 711, '2017-09-25 18:55:29'),
(103, 1179, 66, '<font color=red>Suche:&nbsp;</font>Klein Erna auf dem Jungfernstieg', 'Klein Erna auf dem Jungfernstieg', '2017-09-28 17:17:32', 0, 0, '0000-00-00 00:00:00'),
(100, 785, 69, '<font color=red>Suche:&nbsp;</font>Minimal Techno', 'suche von Minimal Techno alles von alt bis neu', '2017-09-14 23:50:34', 35125, 712, '2017-09-15 01:01:53'),
(107, 782, 66, '<font color=red>Suche:&nbsp;</font>Fack ju Goethe 3', 'Hat den schon jemand..w&auml;re supi', '2017-11-02 20:26:42', 0, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `reseed`
--

CREATE TABLE IF NOT EXISTS `reseed` (
  `torrentid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
`id` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rules_categories`
--

CREATE TABLE IF NOT EXISTS `rules_categories` (
`id` int(11) NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `short` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `sort` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `rules_categories`
--

INSERT INTO `rules_categories` (`id`, `name`, `short`, `sort`) VALUES
(10, 'Unsere European Gamer Community Server Regeln', 'egcrules', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rules_questions`
--

CREATE TABLE IF NOT EXISTS `rules_questions` (
`id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `question` text COLLATE latin1_general_ci NOT NULL,
  `answer` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `rules_questions`
--

INSERT INTO `rules_questions` (`id`, `category`, `question`, `answer`) VALUES
(26, 10, '<div class="card-header">[>EGC<] WC3 Publuc</div>', '		Rule #1: No racism of any kind<br><br>\r\n		Rule #2: No clan stacking, members must split evenly between the teams<br><br>\r\n		Rule #3: No arguing with admins (listen and learn or leave)<br><br>\r\n		Rule #4: No abusive language or behavior towards admins or other players<br><br>\r\n		Rule #5: No offensive or potentially offensive names, annoying names, or in-game (double caret (^)) color in names<br><br>\r\n		Rule #6: No recruiting for your clan, your server, or anything else<br><br>\r\n		Rule #7: No advertising or spamming of websites or servers<br><br>\r\n		Rule #8: No profanity or offensive language (in any language)<br><br>\r\n		Rule #9: Do NOT fire at teammates or within 10 seconds of spawning<br><br>\r\n		Rule #10: Offense players must play for the objective and support their team<br><br>'),
(21, 0, '[>EGC<] European Gamer Community', '		Rule #1: No racism of any kind\r\n		Rule #2: No clan stacking, members must split evenly between the teams\r\n		Rule #3: No arguing with admins (listen and learn or leave)\r\n		Rule #4: No abusive language or behavior towards admins or other players\r\n		Rule #5: No offensive or potentially offensive names, annoying names, or in-game (double caret (^)) color in names\r\n		Rule #6: No recruiting for your clan, your server, or anything else\r\n		Rule #7: No advertising or spamming of websites or servers\r\n		Rule #8: No profanity or offensive language (in any language)\r\n		Rule #9: Do NOT fire at teammates or within 10 seconds of spawning\r\n		Rule #10: Offense players must play for the objective and support their team'),
(22, 10, '<div class=''card-header''>[>EGC<] European Gamer Community</div>', '		Rule #1: No racism of any kind<br><br>\r\n		Rule #2: No clan stacking, members must split evenly between the teams<br><br>\r\n		Rule #3: No arguing with admins (listen and learn or leave)<br><br>\r\n		Rule #4: No abusive language or behavior towards admins or other players<br><br>\r\n		Rule #5: No offensive or potentially offensive names, annoying names, or in-game (double caret (^)) color in names<br><br>\r\n		Rule #6: No recruiting for your clan, your server, or anything else<br><br>\r\n		Rule #7: No advertising or spamming of websites or servers<br><br>\r\n		Rule #8: No profanity or offensive language (in any language)<br><br>\r\n		Rule #9: Do NOT fire at teammates or within 10 seconds of spawning<br><br>\r\n		Rule #10: Offense players must play for the objective and support their team<br><br>'),
(25, 10, '<div class="card-header">[>EGC<] Modern Promod</div>', '		Rule #1: No racism of any kind<br><br>\r\n		Rule #2: No clan stacking, members must split evenly between the teams<br><br>\r\n		Rule #3: No arguing with admins (listen and learn or leave)<br><br>\r\n		Rule #4: No abusive language or behavior towards admins or other players<br><br>\r\n		Rule #5: No offensive or potentially offensive names, annoying names, or in-game (double caret (^)) color in names<br><br>\r\n		Rule #6: No recruiting for your clan, your server, or anything else<br><br>\r\n		Rule #7: No advertising or spamming of websites or servers<br><br>\r\n		Rule #8: No profanity or offensive language (in any language)<br><br>\r\n		Rule #9: Do NOT fire at teammates or within 10 seconds of spawning<br><br>\r\n		Rule #10: Offense players must play for the objective and support their team<br><br>');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `shoutbox`
--

CREATE TABLE IF NOT EXISTS `shoutbox` (
`id` int(3) NOT NULL,
  `userid` int(10) NOT NULL,
  `username` int(3) NOT NULL,
  `date` int(11) NOT NULL DEFAULT '0',
  `text` text,
  `text_c` text
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `shoutbox`
--

INSERT INTO `shoutbox` (`id`, `userid`, `username`, `date`, `text`, `text_c`) VALUES
(1, 0, 0, 1510916882, '[b]I''m horny and that''s why the shoutbox is now empty.[/b]', '<b>I''m horny and that''s why the shoutbox is now empty.</b>'),
(2, 0, 0, 1510933239, 'Der User Str1k3r hat sich ausgeloggt !', NULL),
(3, 10, 0, 1511035682, 'hi', 'hi');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `sitelog`
--

CREATE TABLE IF NOT EXISTS `sitelog` (
`id` int(10) unsigned NOT NULL,
  `typ` enum('torrentupload','torrentedit','torrentdelete','promotion','demotion','addwarn','remwarn','security_tactics','accenabled','accdisabled','accdeleted','waitgrant','waitreject','passkeyreset','torrentgranted','Kategorien','autowarn','autodewarn','autoban','passkeyadminreset','ctracker','Rausschmiss','denied','cleanup') COLLATE latin1_general_ci NOT NULL DEFAULT 'torrentupload',
  `added` datetime DEFAULT NULL,
  `txt` text COLLATE latin1_general_ci
) ENGINE=MyISAM AUTO_INCREMENT=204 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `slot_machine_tp`
--

CREATE TABLE IF NOT EXISTS `slot_machine_tp` (
`id` int(11) unsigned NOT NULL,
  `uploaded` bigint(20) unsigned NOT NULL DEFAULT '5368709120'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `slot_machine_tp`
--

INSERT INTO `slot_machine_tp` (`id`, `uploaded`) VALUES
(1, 11785994240);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `smilies`
--

CREATE TABLE IF NOT EXISTS `smilies` (
`id` int(3) unsigned NOT NULL,
  `code` varchar(30) NOT NULL,
  `path` varchar(100) NOT NULL,
  `active` enum('yes','no') NOT NULL DEFAULT 'yes',
  `private` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=MyISAM AUTO_INCREMENT=136 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `smilies`
--

INSERT INTO `smilies` (`id`, `code`, `path`, `active`, `private`) VALUES
(1, ':ha:', '01.png', 'yes', 'no'),
(2, ':zwinker:', '02.png', 'yes', 'no'),
(3, ':zwinker2:', '03.png', 'yes', 'no'),
(4, ':zwinker3:', '04.png', 'yes', 'no'),
(5, ':love:', '05.png', 'yes', 'no'),
(6, ':love1:', '06.png', 'yes', 'no'),
(7, ':hihi:', '07.png', 'yes', 'no'),
(8, ':hihi1:', '08.png', 'yes', 'no'),
(9, ':puh:', '09.png', 'yes', 'no'),
(10, ':puh1:', '10.png', 'yes', 'no'),
(11, ':love3:', '11.png', 'yes', 'no'),
(12, ':grr:', '12.png', 'yes', 'no'),
(13, ':grr1:', '13.png', 'yes', 'no'),
(14, ':freaky:', '14.png', 'yes', 'no'),
(15, ':freaky1:', '15.png', 'yes', 'no'),
(16, ':puh4:', '16.png', 'yes', 'no'),
(17, ':cool:', '17.png', 'yes', 'no'),
(18, ':heul:', '18.png', 'yes', 'no'),
(19, ':heul2:', '19.png', 'yes', 'no'),
(20, ':oh:', '20.png', 'yes', 'no'),
(21, ':wat:', '21.png', 'yes', 'no'),
(22, ':wat1:', '22.png', 'yes', 'no'),
(23, ':lol:', '23.png', 'yes', 'no'),
(24, ':lol2:', '24.png', 'yes', 'no'),
(25, ':stern:', '25.png', 'yes', 'no'),
(26, ':zunge:', '26.png', 'yes', 'no'),
(27, ':hehe:', '27.png', 'yes', 'no'),
(28, ':nn:', '28.png', 'yes', 'no'),
(29, ':ooooh:', '29.png', 'yes', 'no'),
(30, ':heul5:', '30.png', 'yes', 'no'),
(31, ':freaky2:', '31.png', 'yes', 'no'),
(32, ':zunge3:', '32.png', 'yes', 'no'),
(33, ':hehe2:', '33.png', 'yes', 'no'),
(34, ':sauer:', '34.png', 'yes', 'no'),
(35, ':ztz:', '35.png', 'yes', 'no'),
(36, ':hehe4:', '36.png', 'yes', 'no'),
(37, ':ooooh2:', '37.png', 'yes', 'no'),
(38, ':hihi6:', '38.png', 'yes', 'no'),
(39, ':uha:', '39.png', 'yes', 'no'),
(40, ':freu:', '40.png', 'yes', 'no'),
(41, ':vv:', '41.png', 'yes', 'no'),
(42, ':aua:', '42.png', 'yes', 'no'),
(43, ':uf:', '43.png', 'yes', 'no'),
(44, ':ohman:', '44.png', 'yes', 'no'),
(45, ':haha:', '45.png', 'yes', 'no'),
(46, ':ui:', '46.png', 'yes', 'no'),
(47, ':huhu7:', '47.png', 'yes', 'no'),
(48, ':wat8:', '48.png', 'yes', 'no'),
(49, ':ente:', '49.png', 'yes', 'no'),
(50, ':teufel:', '50.png', 'yes', 'no'),
(51, ':5x1:', '51.png', 'yes', 'no'),
(52, ':psst:', '52.png', 'yes', 'no'),
(53, ':love2:', '53.png', 'yes', 'no'),
(54, ':he:', '54.png', 'yes', 'no'),
(55, ':neeeeee:', '55.png', 'yes', 'no'),
(56, ':smilie:', '56.png', 'yes', 'no'),
(57, ':zunge7:', '57.png', 'yes', 'no'),
(58, ':kiss:', '58.png', 'yes', 'no'),
(59, ':essen:', '59.png', 'yes', 'no'),
(60, ':kiss2:', '60.png', 'yes', 'no'),
(61, ':kk:', '61.png', 'yes', 'no'),
(62, ':muede:', '62.png', 'yes', 'no'),
(63, ':ka:', '63.png', 'yes', 'no'),
(64, ':64:', '64.png', 'yes', 'no'),
(65, ':muede2:', '65.png', 'yes', 'no'),
(66, ':haha2:', '66.png', 'yes', 'no'),
(67, ':aua3:', '67.png', 'yes', 'no'),
(68, ':heul4:', '68.png', 'yes', 'no'),
(69, ':krank:', '69.png', 'yes', 'no'),
(70, ':70:', '70.png', 'yes', 'no'),
(71, ':sauer9:', '71.png', 'yes', 'no'),
(72, ':cool3:', '79.png', 'yes', 'no'),
(73, ':require:', 'Blue.png', 'yes', 'no'),
(74, ':wuschel:', 'Cyan.png', 'yes', 'no'),
(75, ':opatechno:', 'Green.png', 'yes', 'no'),
(76, ':sirrah:', 'Orange.png', 'yes', 'no'),
(77, ':pops:', 'Purple.png', 'yes', 'no'),
(78, ':tornado:', 'Red.png', 'yes', 'no'),
(79, ':ruberduck58:', 'Yellow.png', 'yes', 'no'),
(80, ':rose:', '77.png', 'yes', 'no'),
(81, ':gutenabend:', 'gutenabend.gif', 'yes', 'no'),
(92, ':gutenmorgen:', 'gifanpr5.gif', 'yes', 'no'),
(83, ':mahlzeit:', 'mahlzeit.gif', 'yes', 'no'),
(84, ':gutenacht:', 'gutenacht.gif', 'yes', 'no'),
(93, ':dance:', 'dance.gif', 'yes', 'no'),
(106, ':blush:', 'blush.gif', 'yes', 'no'),
(95, ':gassi:', 'gassi.gif', 'yes', 'no'),
(96, ':huhu:', 'huhu.gif', 'yes', 'no'),
(97, ':kaffee:', 'kaffee.gif', 'yes', 'no'),
(98, ':kissen:', 'kissen.gif', 'yes', 'no'),
(99, ':kuss:', 'kuss.gif', 'yes', 'no'),
(100, ':pennen:', 'pennen.gif', 'yes', 'no'),
(101, ':prost:', 'prost.gif', 'yes', 'no'),
(102, ':ts:', 'ts.gif', 'yes', 'no'),
(103, ':polizei:', 'polizei.gif', 'yes', 'no'),
(104, ':platt:', 'platt.gif', 'yes', 'no'),
(107, ':aetsch:', 'aetsch.gif', 'yes', 'no'),
(108, ':hau:', 'hau.gif', 'yes', 'no'),
(121, ':oki:', 'oki.gif', 'yes', 'no'),
(110, ':daumen:', 'daumen.gif', 'yes', 'no'),
(111, ':erpel:', 'erpel.gif', 'yes', 'no'),
(112, ':jawohl:', 'jawohl.gif', 'no', 'no'),
(113, ':lieb:', 'lieb.gif', 'yes', 'no'),
(120, ':zunge1:', 'Zunge 1.gif', 'yes', 'no'),
(115, ':nachti:', 'nachti.gif', 'yes', 'no'),
(116, ':radio:', 'radio.gif', 'yes', 'no'),
(117, ':test:', 'test.gif', 'yes', 'no'),
(118, ':regen:', 'regen.gif', 'yes', 'no'),
(119, ':grinz:', 'grinz.gif', 'yes', 'no'),
(122, ':kaffee2:', 't_kaffee1.gif', 'yes', 'no'),
(123, ':siggi:', 'pic2.gif', 'yes', 'no'),
(124, ':creazy:', 'irre11.gif', 'yes', 'no'),
(125, ':creazy2:', 'balamm-fu.gif', 'yes', 'no'),
(126, ':kaffee1:', 'kaffeetrinken.gif', 'yes', 'no'),
(127, ':nein:', 'nein.finger.gif', 'yes', 'no'),
(128, ':rubber:', 'donald duck.gif', 'yes', 'no'),
(129, ':knuddel:', 'KD.gif', 'yes', 'no'),
(130, ':prosti:', 'prosti.png', 'yes', 'no'),
(131, ':techno:', 'techno.gif', 'yes', 'no'),
(132, ':pupsi:', 'pupsi.gif', 'yes', 'no'),
(135, ':brauch:', 'brauch.gif', 'yes', 'no');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `staffacpmenu`
--

CREATE TABLE IF NOT EXISTS `staffacpmenu` (
  `id` int(10) NOT NULL,
  `type` set('haupt','unter') NOT NULL DEFAULT 'haupt',
  `name` text NOT NULL,
  `url` text NOT NULL,
  `class` int(11) NOT NULL DEFAULT '1',
  `haupt` int(10) NOT NULL DEFAULT '0',
  `order` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `staffacpmenu`
--

INSERT INTO `staffacpmenu` (`id`, `type`, `name`, `url`, `class`, `haupt`, `order`) VALUES
(108, 'haupt', 'Site Infos', '#', 25, 0, 1),
(109, 'haupt', 'Developer', '#', 255, 0, 2),
(161, 'unter', 'P-Chat Viewer ACP', 'pchat_viewer_acp.php', 200, 118, 3),
(111, 'unter', 'Tracker Config', 'dev_panel.php', 255, 109, 1),
(112, 'unter', 'Sitelog', 'log.php', 25, 108, 2),
(113, 'unter', 'Staff Rules', 'staffrules.php', 25, 108, 3),
(114, 'unter', 'Team Pms', 'staffbox.php', 25, 108, 4),
(117, 'unter', 'Menu Management', 'navi.php', 255, 109, 4),
(116, 'unter', 'Rules Manager', 'rulesadmin.php', 100, 122, 3),
(118, 'haupt', 'Owner', '#', 200, 0, 3),
(119, 'unter', 'Torrent-Bereiniger', 'old_tfiles_acp.php', 200, 118, 1),
(120, 'unter', 'PM Spion', 'pm_spion_acp.php', 200, 118, 2),
(122, 'haupt', 'SysOp', '#', 100, 0, 5),
(123, 'unter', 'Staff Rules Manager', 'staffrulesadmin.php', 101, 178, 1),
(155, 'unter', 'Nameserver Lookup', 'nameserver_acp.php', 255, 109, 9),
(125, 'haupt', 'Moderator', '#', 25, 0, 7),
(135, 'unter', 'Style Manager', 'themecp.php', 255, 109, 6),
(152, 'unter', 'Partner Verwaltung', 'add_partners.php', 101, 178, 8),
(153, 'unter', 'Cleanup ACP', 'cleanup_dev_acp.php', 255, 109, 8),
(139, 'unter', 'User Foundation', 'user_foundation.php', 25, 125, 9),
(140, 'unter', 'Client Manager', 'cp_agents.php', 100, 122, 6),
(141, 'unter', 'Benutzer suchen', 'usersearch.php', 25, 125, 10),
(160, 'unter', 'Backend Navi ACP', 'staff_navi_acp.php', 255, 109, 12),
(151, 'unter', 'Tracker Stats ACP', 'trackerstats_acp.php', 101, 178, 7),
(149, 'unter', 'Unbest&auml;tigte User', 'unuser.php', 25, 125, 11),
(159, 'unter', 'Memcached System', 'memtest.php', 255, 109, 11),
(164, 'unter', 'Only Upload ACP', 'onlyup_acp.php', 101, 178, 9),
(166, 'unter', 'Security Tactics Bans', 'bans_acp.php', 200, 118, 4),
(169, 'haupt', 'Admin', '#', 50, 0, 6),
(170, 'unter', 'FAQ Manager', 'faqadmin.php', 50, 169, 1),
(172, 'unter', 'Smilie Manager ACP', 'smilie_manager_acp.php', 101, 178, 10),
(173, 'unter', 'News Center', 'news.php', 50, 169, 13),
(174, 'unter', 'Account erstellen', 'add_user.php', 50, 169, 2),
(175, 'unter', 'Radio Server Interface', 'dj_acp_radio.php', 9, 176, 0),
(176, 'haupt', 'DJ Options', '#', 9, 0, 8),
(177, 'unter', 'Massen GBs', 'massgift.php', 100, 122, 11),
(178, 'haupt', 'Teamleitung', '#', 101, 0, 4),
(179, 'unter', 'Massen E-Mail', 'massmail.php', 100, 122, 12),
(180, 'haupt', 'Partner Options', '#', 7, 0, 9),
(0, 'unter', 'User Info Center', 'partner_acp_uic.php', 7, 180, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `staffmessages`
--

CREATE TABLE IF NOT EXISTS `staffmessages` (
`id` int(10) unsigned NOT NULL,
  `sender` int(10) unsigned NOT NULL DEFAULT '0',
  `added` datetime DEFAULT NULL,
  `msg` text,
  `subject` varchar(100) NOT NULL DEFAULT '',
  `answeredby` int(10) unsigned NOT NULL DEFAULT '0',
  `answered` tinyint(1) NOT NULL DEFAULT '0',
  `answer` text,
  `readed` varchar(20) NOT NULL DEFAULT 'no'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `staffrules_categories`
--

CREATE TABLE IF NOT EXISTS `staffrules_categories` (
`id` int(11) NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `short` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `sort` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `staffrules_categories`
--

INSERT INTO `staffrules_categories` (`id`, `name`, `short`, `sort`) VALUES
(3, 'Willkommen bei den Staff Rules', 'x264sr', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `staffrules_questions`
--

CREATE TABLE IF NOT EXISTS `staffrules_questions` (
`id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `question` text COLLATE latin1_general_ci NOT NULL,
  `answer` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `staffrules_questions`
--

INSERT INTO `staffrules_questions` (`id`, `category`, `question`, `answer`) VALUES
(3, 3, 'Staff Rules Informationen', '<div class=''x264_wrapper_content_out_mount''>\r\n<h1 class=''x264_im_logo''>Willkommen auf unseren Tracker.</h1>\r\n	<div class=''x264_title_content''>\r\n		<div class=''x264_title_table''>In diesen Staff Rules System kannst du deine Staff Rules selbst bearbeiten und zwar direkt auf den Tracker.</div>\r\n		<div class=''x264_title_table''>Wir wünschen dir viel Spass mit der D€ Source von D@rk-€vil™.</a></div>\r\n	</div>\r\n</div>\r\n</div>');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `startstoplog`
--

CREATE TABLE IF NOT EXISTS `startstoplog` (
  `userid` int(10) NOT NULL DEFAULT '0',
  `event` enum('start','stop') NOT NULL DEFAULT 'start',
  `datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `torrent` int(10) NOT NULL DEFAULT '0',
  `ip` varchar(256) NOT NULL DEFAULT '',
  `peerid` varchar(20) NOT NULL DEFAULT '',
  `useragent` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `teambox`
--

CREATE TABLE IF NOT EXISTS `teambox` (
`id` smallint(6) NOT NULL,
  `userid` smallint(6) NOT NULL DEFAULT '0',
  `username` varchar(25) NOT NULL DEFAULT '',
  `date` int(11) NOT NULL DEFAULT '0',
  `text` text CHARACTER SET latin1 COLLATE latin1_german1_ci NOT NULL,
  `text_c` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `teammembers`
--

CREATE TABLE IF NOT EXISTS `teammembers` (
`id` int(10) unsigned NOT NULL,
  `teamid` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `leader` enum('no','yes') NOT NULL DEFAULT 'no'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `teams`
--

CREATE TABLE IF NOT EXISTS `teams` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `banner` varchar(100) NOT NULL DEFAULT '',
  `typ` enum('support','crew') NOT NULL DEFAULT 'support',
  `suffix` varchar(100) NOT NULL DEFAULT '',
  `sort` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `thanks`
--

CREATE TABLE IF NOT EXISTS `thanks` (
  `torrentid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
`id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `topics`
--

CREATE TABLE IF NOT EXISTS `topics` (
`id` int(10) unsigned NOT NULL,
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(40) DEFAULT NULL,
  `locked` enum('yes','no') NOT NULL DEFAULT 'no',
  `forumid` int(10) unsigned NOT NULL DEFAULT '0',
  `lastpost` int(10) unsigned NOT NULL DEFAULT '0',
  `sticky` enum('yes','no') NOT NULL DEFAULT 'no',
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `guestuser` enum('yes','no') NOT NULL DEFAULT 'no',
  `guestname` varchar(40) NOT NULL,
  `guestmail` varchar(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `torrents`
--

CREATE TABLE IF NOT EXISTS `torrents` (
`id` int(10) unsigned NOT NULL,
  `info_hash` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `filename` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `save_as` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `search_text` text COLLATE latin1_general_ci NOT NULL,
  `descr` text COLLATE latin1_general_ci NOT NULL,
  `ori_descr` text COLLATE latin1_general_ci NOT NULL,
  `category` int(10) unsigned NOT NULL DEFAULT '0',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0',
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `preTime` datetime NOT NULL,
  `type` enum('single','multi') COLLATE latin1_general_ci NOT NULL DEFAULT 'single',
  `numfiles` int(10) unsigned NOT NULL DEFAULT '0',
  `numpics` int(1) NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `times_completed` int(10) unsigned NOT NULL DEFAULT '0',
  `leechers` int(10) unsigned NOT NULL DEFAULT '0',
  `seeders` int(10) unsigned NOT NULL DEFAULT '0',
  `last_action` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'yes',
  `banned` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `activated` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'yes',
  `owner` int(10) unsigned NOT NULL DEFAULT '0',
  `gu_agent` int(10) unsigned NOT NULL DEFAULT '0',
  `numratings` int(10) unsigned NOT NULL DEFAULT '0',
  `ratingsum` int(10) unsigned NOT NULL DEFAULT '0',
  `nfo` text COLLATE latin1_general_ci NOT NULL,
  `free` enum('yes','no') COLLATE latin1_general_ci DEFAULT 'no',
  `requested` enum('yes','no') COLLATE latin1_general_ci DEFAULT 'no',
  `seedspeed` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT 'n/a',
  `nuked` enum('yes','no','unnuked') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `nukereason` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `pic1` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `pic2` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `pic1th` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `pic2th` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `irc` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `team` int(10) NOT NULL DEFAULT '0',
  `highlight` enum('yes','no') COLLATE latin1_general_ci DEFAULT 'no',
  `wonly` enum('yes','no') COLLATE latin1_general_ci DEFAULT 'no',
  `multiplikator` tinyint(3) unsigned DEFAULT '1',
  `language` enum('deutsch','englisch','multi','na') COLLATE latin1_general_ci NOT NULL DEFAULT 'deutsch',
  `root` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `freeuntil` date NOT NULL DEFAULT '0000-00-00',
  `freetime` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `ratio` int(10) unsigned NOT NULL DEFAULT '0',
  `gu_bonus` enum('requested','accepted','declined','none') COLLATE latin1_general_ci DEFAULT 'none',
  `tsize` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `allfreeleech` enum('yes','no') COLLATE latin1_general_ci DEFAULT 'no',
  `freeleech` enum('yes','no') COLLATE latin1_general_ci DEFAULT 'no',
  `allmulti` enum('yes','no') COLLATE latin1_general_ci NOT NULL,
  `imdb` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `last_reseed` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tvdb` text COLLATE latin1_general_ci
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `traffic`
--

CREATE TABLE IF NOT EXISTS `traffic` (
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `torrentid` int(11) unsigned NOT NULL DEFAULT '0',
  `downloaded` bigint(20) unsigned NOT NULL DEFAULT '0',
  `uploaded` bigint(20) unsigned NOT NULL DEFAULT '0',
  `downloadtime` int(11) unsigned NOT NULL DEFAULT '0',
  `uploadtime` int(11) unsigned NOT NULL DEFAULT '0',
  `seedtime` int(100) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `userclass`
--

CREATE TABLE IF NOT EXISTS `userclass` (
  `id` int(2) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `classname` varchar(50) NOT NULL,
  `class` int(3) NOT NULL,
  `color` varchar(10) NOT NULL,
  `style` int(3) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `userclass`
--

INSERT INTO `userclass` (`id`, `name`, `classname`, `class`, `color`, `style`) VALUES
(10, 'MODERATOR', 'Moderator', 25, '#ffcc66', 1),
(12, 'SYSOP', 'SysOp', 100, '#FF0000', 1),
(11, 'ADMINISTRATOR', 'Admin', 50, '#ff9900', 1),
(7, 'UPLOADER', 'Uploader', 11, '#00d1ff', 1),
(5, 'VIP', 'VIP', 5, '#0082ff', 1),
(3, 'XTREMUSER', 'Extreme User', 3, '#00ffcc', 1),
(2, 'POWER_USER', 'Power User', 1, '#339933', 1),
(1, 'USER', 'User', 0, '#ffffff', 1),
(13, 'DEV', 'Developer', 255, '#339966', 1),
(14, 'BOSS', 'Super Admin', 200, '#00cc00', 1),
(6, 'EHRENMITGLIED', 'Friends', 6, '#6495ed', 1),
(9, 'DJ', 'Dj', 9, '#00ff00', 1),
(8, 'PARTNER', 'Partner', 7, '#58FAF4', 1),
(22, 'TEAMLEITUNG', 'Teamleitung', 101, '#999966', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `username` varchar(40) NOT NULL DEFAULT '',
  `old_password` varchar(40) NOT NULL DEFAULT '',
  `passhash` varchar(32) NOT NULL DEFAULT '',
  `passkey` tinyblob NOT NULL,
  `secret` tinyblob NOT NULL,
  `email` varchar(80) NOT NULL DEFAULT '',
  `status` enum('pending','confirmed') NOT NULL DEFAULT 'confirmed',
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_access` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editsecret` tinyblob NOT NULL,
  `privacy` enum('strong','normal','low') NOT NULL DEFAULT 'normal',
  `design` int(10) DEFAULT '1',
  `info` text,
  `acceptpms` enum('yes','friends','no') NOT NULL DEFAULT 'yes',
  `ip` varchar(256) NOT NULL DEFAULT '',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `avatar` varchar(100) NOT NULL DEFAULT '',
  `uploaded` bigint(20) unsigned NOT NULL DEFAULT '5368709120',
  `downloaded` bigint(20) unsigned NOT NULL DEFAULT '10',
  `title` varchar(30) NOT NULL DEFAULT '',
  `country` int(10) unsigned NOT NULL DEFAULT '0',
  `notifs` varchar(200) NOT NULL DEFAULT '',
  `enabled` enum('yes','no') NOT NULL DEFAULT 'yes',
  `accept_rules` enum('yes','no') NOT NULL DEFAULT 'yes',
  `accept_email` enum('yes','friends','no') NOT NULL DEFAULT 'friends',
  `avatars` enum('yes','no') NOT NULL DEFAULT 'yes',
  `donor` enum('yes','no') NOT NULL DEFAULT 'no',
  `oldtorrentlist` enum('yes','no') NOT NULL DEFAULT 'no',
  `displaysearch` enum('yes','no') NOT NULL DEFAULT 'yes',
  `warned` enum('yes','no') NOT NULL DEFAULT 'no',
  `log_ratio` enum('yes','no') NOT NULL DEFAULT 'no',
  `statbox` enum('top','bottom','hide') NOT NULL DEFAULT 'top',
  `warneduntil` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `torrentsperpage` int(3) unsigned NOT NULL DEFAULT '0',
  `topicsperpage` int(3) unsigned NOT NULL DEFAULT '0',
  `postsperpage` int(3) unsigned NOT NULL DEFAULT '0',
  `deletepms` enum('yes','no') NOT NULL DEFAULT 'yes',
  `savepms` enum('yes','no') NOT NULL DEFAULT 'no',
  `hideuseruploads` enum('yes','no') NOT NULL DEFAULT 'no',
  `wgeturl` enum('yes','no') NOT NULL DEFAULT 'no',
  `showcols` text NOT NULL,
  `tlimitall` int(10) NOT NULL DEFAULT '0',
  `tlimitseeds` int(10) NOT NULL DEFAULT '0',
  `tlimitleeches` int(10) NOT NULL DEFAULT '0',
  `allowupload` enum('yes','no') NOT NULL DEFAULT 'yes',
  `navistatus` text,
  `anonymous` enum('yes','no') NOT NULL DEFAULT 'yes',
  `shoutpost` enum('yes','no') NOT NULL DEFAULT 'yes',
  `afk` enum('yes','no') NOT NULL DEFAULT 'no',
  `xxx` enum('yes','no') NOT NULL DEFAULT 'no',
  `sbtorrentpost` enum('yes','no') NOT NULL DEFAULT 'yes',
  `bgshout` enum('1','2','3','4','5','6','7','8','9','10') NOT NULL DEFAULT '1',
  `upperstatus` int(255) NOT NULL DEFAULT '0',
  `dsl_speed` enum('0','DSL 1000','DSL 2000','DSL 6000','DSL 16000','VDSL 20000','VDSL 25000','VDSL 30000','VDSL 50000','VDSL 100000','VDSL 150000','VDSL 200000','Root') NOT NULL DEFAULT '0',
  `secure_code` smallint(12) unsigned DEFAULT NULL,
  `pcoff` enum('yes','no') NOT NULL DEFAULT 'no',
  `seed_angaben` varchar(15) NOT NULL,
  `anon` enum('no','yes') NOT NULL DEFAULT 'no',
  `upperbonus` int(255) NOT NULL DEFAULT '0',
  `seedbonus` decimal(10,1) NOT NULL,
  `tlist` enum('10','20','30','40','50') NOT NULL DEFAULT '30',
  `tstdn` enum('12','24','48','72') NOT NULL DEFAULT '24',
  `ajax_browse` int(10) unsigned NOT NULL,
  `ajax_browse_datafield` int(1) NOT NULL DEFAULT '15',
  `adsl` enum('yes','no') NOT NULL DEFAULT 'no',
  `webseed` enum('yes','no') NOT NULL DEFAULT 'no',
  `vdsl` enum('yes','no') NOT NULL DEFAULT 'no',
  `allowdownload` enum('yes','no') DEFAULT 'yes',
  `systemwarn` enum('yes','no') NOT NULL DEFAULT 'no',
  `permban` enum('yes','no') NOT NULL DEFAULT 'no',
  `warnedby` varchar(40) NOT NULL DEFAULT '',
  `donoruntil` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `atworkcount` int(100) NOT NULL,
  `atwork` enum('yes','no') NOT NULL DEFAULT 'no',
  `anonym` enum('no','yes') NOT NULL DEFAULT 'no',
  `hradio` enum('yes','no') NOT NULL DEFAULT 'yes',
  `slcount` bigint(20) NOT NULL DEFAULT '0',
  `randtid` varchar(32) NOT NULL DEFAULT '0',
  `rooter` enum('yes','no') NOT NULL DEFAULT 'no',
  `showrec` enum('yes','no') DEFAULT 'yes',
  `warnings` int(10) NOT NULL DEFAULT '0',
  `announce` enum('yes','no') CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'yes',
  `downtime` int(10) unsigned NOT NULL DEFAULT '0',
  `hideprofile` enum('yes','no') NOT NULL DEFAULT 'yes',
  `freeslsystem` enum('yes','no') NOT NULL DEFAULT 'no',
  `support1` enum('yes','no') NOT NULL DEFAULT 'no',
  `seedfrom` int(5) NOT NULL DEFAULT '0',
  `seedto` int(5) NOT NULL DEFAULT '0',
  `pchat` enum('yes','no') NOT NULL DEFAULT 'yes',
  `signature` varchar(225) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `uploadoff` enum('yes','no') NOT NULL DEFAULT 'no',
  `new_tag` enum('automatik','manuell') NOT NULL DEFAULT 'manuell',
  `forum_access` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `timeswarned` int(10) NOT NULL DEFAULT '0',
  `lastwarned` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `browser` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `bootstrap_design` int(10) DEFAULT '1',
  `sig` text CHARACTER SET latin1 COLLATE latin1_german1_ci,
  `ajax_tfiles` enum('yes','no') NOT NULL DEFAULT 'yes',
  `session` varchar(255) NOT NULL,
  `invites` int(10) NOT NULL DEFAULT '1',
  `invitedby` int(10) NOT NULL DEFAULT '0',
  `design_loader` enum('ajax','static') NOT NULL DEFAULT 'ajax',
  `rss_key` varchar(32) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users_secure`
--

CREATE TABLE IF NOT EXISTS `users_secure` (
  `id` int(10) unsigned NOT NULL,
  `users_secure` varchar(20) NOT NULL,
  `hash` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `votes`
--

CREATE TABLE IF NOT EXISTS `votes` (
`id` int(10) unsigned NOT NULL,
  `what` enum('requests') NOT NULL DEFAULT 'requests',
  `user` int(10) unsigned NOT NULL DEFAULT '0',
  `voteid` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=115 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wiki`
--

CREATE TABLE IF NOT EXISTS `wiki` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `body` longtext CHARACTER SET utf8,
  `userid` int(10) unsigned DEFAULT '0',
  `time` int(11) NOT NULL,
  `lastedit` int(10) unsigned DEFAULT NULL,
  `lastedituser` int(10) unsigned DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `wiki`
--

INSERT INTO `wiki` (`id`, `name`, `body`, `userid`, `time`, `lastedit`, `lastedituser`) VALUES
(1, 'index', '[size=6]Willkommen in der [b]Wiki[/b] von Power Castle![/size]\r\n\r\n[size=4]Haltet euch bitte an unsere Community Regeln![/size]\r\n\r\n[size=4]Mit freundlichen Grüßen[/size]\r\n\r\n[size=4]Das Power Castle Team[/size]', 0, 1228076412, 0, 1),
(3, 'BitTorrent-Protokoll', 'BitTorrent (Bit: kleinste Daten-Einheit, engl. torrent: reißender Strom od. Sturzbach, von lat. torrens) ist ein kollaboratives Filesharing-Protokoll, das sich besonders für die schnelle Verteilung großer Datenmengen eignet. Im Gegensatz zu anderen Filesharing-Techniken setzt BitTorrent nicht auf ein übergreifendes Filesharing-Netzwerk, sondern baut für jede Datei ein separates Verteilnetz auf.\r\nTechnik\r\n\r\nTechnisch ist das Protokoll der OSI-Schicht 7, also der Anwendungsschicht, zuzuordnen und setzt auf das TCP/IP-Referenzmodell auf. Die Referenzimplementierung durch den Erfinder Bram Cohen erfolgte ursprünglich in der Programmiersprache Python. Mittlerweile steht eine Reihe alternativer Programme zur Verfügung, die das BitTorrent-Protokoll implementieren.\r\n\r\nBitTorrent reduziert die Serverauslastung, da sich Peers, auch mit unvollständigen Dateien, untereinander austauschen. Wie die farbigen Balken bei einigen Clients anzeigen, wird die Datei stückweise in zufälliger Reihenfolge untereinander ausgetauscht, anstatt sie komplett zu laden.\r\nIm Vergleich zum herkömmlichen Herunterladen einer Datei mittels HTTP oder FTP werden bei der BitTorrent-Technik die (ansonsten ungenutzten) Upload-Kapazitäten der Downloader mitgenutzt, auch wenn sie die Datei noch nicht vollständig heruntergeladen haben. Dateien werden also nicht nur von einem Server verteilt, sondern auch von Nutzer zu Nutzer (Peer-to-Peer oder P2P). Das belastet den Server weniger und der Anbieter spart Kosten. Insgesamt ist die Downloadlast nicht geringer, sie wird lediglich auf die einzelnen Nutzer verlagert. Bei populären Dateien verhindert diese Technik das Zusammenbrechen des Netzes infolge des Überschreitens der Kapazitätsgrenzen des Anbieters.\r\nFunktionen\r\n\r\nUm sich an der Verteilung der Daten eines Torrents zu beteiligen, benutzt der Client üblicherweise eine Torrent-Datei (Dateinamenserweiterung .torrent oder .tor). In dieser befindet sich die IP-Adresse (bzw. der Hostname) des Trackers sowie Dateiname, Größe und eine Liste von Prüfsummen von Segmenten der herunterzuladenden Daten (eine oder mehrere Dateien). Torrent-Dateien können mit vielen verfügbaren Bittorrent-Clients erzeugt werden. Dabei muss der initiale Seeder-Peer (engl. "seeder" = Entkerner; Sämaschine) die Verknüpfung zur als Torrent anzubietenden Datei herstellen und diese verfügbar halten.\r\n\r\nFür das Finden anderer (an einer bestimmten Datei interessierter) Peers gibt es neben mittlerweile mehreren anderen Möglichkeiten ein System, bei dem von speziellen (Web-)Servern – den Trackern (engl. "track" = verfolgen) – der Kontakt vermittelt wird. Der Tracker hält im Normalfall lediglich eine eindeutige ID des Torrents lokal vor, der die IP-Adressen der Peers zugeordnet sind, welche die Datei verfügbar halten. Peers nehmen recht häufig Verbindung zum Tracker auf, um auf Änderungen in den verfügbaren Peers schnell reagieren zu können.\r\n\r\nTorrents sind üblicherweise wenige dutzend Kilobytes groß und werden auf der Website des Anbieters oder über Index-Sites (zum Beispiel The Pirate Bay, Mininova oder isoHunt) zum Herunterladen bereitgestellt. Ohne Tracker müssen andere Methoden zum Auffinden von Gegenstellen genutzt werden (DHT, PEX, ...), oder es kann nur noch mit schon bekannten Gegenstellen getauscht werden.\r\nDie Client-Software erhält vom Tracker eine Liste von Gegenstellen, die die Daten oder Teile davon haben oder interessiert sind. Sobald ein Peer ein Segment (engl. "chunk") der Datei erhalten und die Prüfsumme verifiziert hat, meldet er dies dem Tracker und kann dieses Dateistück nun schon an die anderen Peers weitergeben. Die Menge aller Peers, die am gleichen Torrent interessiert sind, nennt man Schwarm. Peers, die im Besitz des kompletten Inhalts des Torrents sind, und somit nichts von anderen Clients herunterladen, sondern lediglich Daten verteilen, nennt man Seeder (von engl. to seed: säen). Als Leecher (von engl. leech: Blutegel; -sauger) werden in der Regel die Peers bezeichnet, die noch nicht über den gesamten Torrent-Inhalt verfügen und noch weitere Segmente herunterladen. (Vorwiegend in anderen Zusammenhängen werden zum Teil auch Peers abwertend als "Leecher" bezeichnet, die nur herunterladen, ohne selbst bereits heruntergeladene Segmente weiterzuverteilen und so dem P2P-Prinzip zuwiderhandeln.) Peer bezeichnet allgemein einen mit einem Client verbundenen anderen Client.\r\n\r\nIm Gegensatz zu anderen bekannten Filesharing-Systemen, werden nicht beliebige Dateien aus den Beständen der Teilnehmer ausgetauscht. Vielmehr verteilt jeder Schwarm nur die Dateien, die der Autor der Torrent-Datei explizit zum Herunterladen vorgesehen hat. Auch der Betreiber des Trackers bestimmt selbst, welche Downloads von diesem verwaltet werden sollen. Die einzelnen Tracker stehen nicht in Verbindung zueinander, es existiert daher kein gemeinsames Netzwerk, sondern ein gesondertes für jeden einzelnen Torrent. So können sich Anbieter auch von fremden, möglicherweise illegalen Inhalten leichter distanzieren.\r\n', 1, 0, NULL, NULL),
(4, 'Debian OS', 'Debian\r\n\r\nDebian ist eine Linux-Distribution, die seit Version 6.0 ausschließlich Freie Software enthält. Debian basiert seit der 1996 veröffentlichten ersten stabilen Version 1.1 Buzz bis zur Version 5.0.8 Lenny auf dem Linux-Kernel.\r\nSeit Version 6.0, Squeeze, wird auch ein FreeBSD-Kernel unterstützt. Ab Version 7.0 Wheezy wird auch GNU Hurd unterstützt werden.\r\n\r\nWeil die meisten grundlegenden Systemwerkzeuge vom GNU-Projekt stammen, wird auch von Debian GNU/Linux gesprochen. Debian enthält eine große Auswahl an Anwendungsprogrammen und Werkzeugen; derzeit sind es über 29.000 Programmpakete.\r\n\r\nDas Debian-Projekt wurde durch Ian Murdock am 16. August 1993 ins Leben gerufen. Heute arbeiten über 1000 Personen mit, die das System zusammenstellen. Debian ist eine der wenigen Distributionen, die sich selbst GNU/Linux nennen (siehe GNU/Linux-Namensstreit).\r\nDas Debian-Projekt folgt damit der Auffassung der Free Software Foundation, dass das Linux genannte Betriebssystem eine Variante des GNU-Systems ist. Debian-Entwickler kann jeder werden, der das sogenannte New-Maintainer-Verfahren erfolgreich durchläuft, das die Bewerber unter anderem darauf testet, ob sie die Ideologie des Projekts teilen.\r\n\r\n\r\nHomepage: https://www.debian.org\r\n\r\nDownload: http://www.debianland.de', 1, 0, 0, 1),
(5, 'Videoformate', 'CAM -\r\n\r\nDie schlechteste aller Aufzeichnungsformen. Der Film wurde mit einem Camcorder im Kino von der Leinwand abgefilmt. Die Bildqualität ist meist akzeptabel bis gut, bei manchen Filmen sind in kurzen Momenten Köpfe von anderen Kinobesuchern im Bild. Die Tonqualität ist sehr unterschiedlich, Störgeräusche wie Gelächter des Publikums sind möglich.\r\n\r\n\r\nTELESYNC (TS) -\r\n\r\nDiese Ripps werden mit einer auf einem Stativ befestigten professionellen (Digital)Kamera in einem leeren Kino von der Leinwand abgefilmt. Die Bildqualität ist wesentlich besser als bei einer Cam. Der Ton wird bei diesen Produktionen oft direkt vom Projektor oder einer anderen externen Quelle abgenommen, ist somit störungsfrei und in der Regel sogar Stereo.\r\n\r\n\r\nTELECINE (TC) -\r\n\r\nDiese Ripps sind sehr selten, bieten dafür aber mit Abstand die beste Qualität. Die Quelle ist ein Filmprojektor mit Audio / Video Ausgang; das Filmmaterial wird hier direkt vom Projektor abgenommen. Bild- und Tonqualität sind exzellent.\r\n\r\n\r\nSCREENER (SCR) -\r\n\r\nDie zweitbeste aller Aufzeichnungsformen. Hier wird als Basis eine Pressekopie von einem professionellen Videoband des Filmes benutzt. Die Bildqualität ist mit sehr gutem VHS vergleichbar. Der Ton ist ebenso einwandfrei, Stereo und oft Dolby Surround.\r\n\r\n\r\nDVDRip -\r\n\r\nHier wurde eine offizielle DVD oder eine Laserdisk als Quelle für den Ripp benutzt. Qualitativ sind diese Versionen exzellent, allerdings sind sie bei neuen Filmen selten zu finden, da die offiziellen DVD oder Laserdisks erst einige Zeit nach Kinostart in den USA auf den Markt kommt. Trotzdem kann die Veröffentlichung vor dem Kinostart in Deutschland liegen, da viele Filme hierzulande mit ca. einem halben Jahr Verzögerung anlaufen.\r\n\r\n\r\nVHSRip -\r\n\r\nFilme die von einer VHS auf gerippt werden Die Qualität ist meist unterschiedlich da die Kasetten meist besser/schlechter aufgenommen wurden.\r\n\r\n\r\nTVRip -\r\n\r\nAufgenommene Serien aus dem TV sind meist mit guter Qualität zu beurteilen, der Ton etc. sind meist wie im TV direkt, das runterladen lohnt sich also.\r\n\r\n\r\nWORKPRINT (WP) -\r\n\r\nEin besonderes Bonbon für Filmfans. Diese Veröffentlichung ist sozusagen eine "Betaversion" eines Films. Ihre Veröffentlichung auf VCD ist meist weit vor dem weltweiten Kinostart. Es ist eine Vorabversion des Films, daher ist qualitativ von exzellent bis fast unanschaubar alles möglich, je nach Quellmaterial. Oft fehlen allerdings noch einige Szenen, oder die Schnitte sind unschlüssig. Positiv ist, dass manchmal Szenen enthalten sind, die im Endprodukt dem Schneidetisch zum Opfer fallen. Bei einigen dieser Produktionen ist am unteren oder oberen Bildrand ein laufender Zähler - ein sogenannter Timecode - der zum Schneiden des Filmmaterials benötigt wird, eingeblendet.\r\n\r\n\r\nWatermarks -\r\n\r\nKleine dauerhafte Einblendungen irgendwelcher Kürzel oder Symbole der Release-Group oder des Verleihers.\r\n\r\n\r\nWeitere Release-Informationen :\r\n\r\n\r\nBAD AR -\r\n\r\nDie Aspect Ratio des Ripps ist nicht korrekt (z.B. Eierköpfe)\r\n\r\n\r\nBAD FPS -\r\n\r\nEin solches Release folgt nicht dem Szene-Standart aufgrund unzureichender/schlechter Framerate (~24fps).\r\n\r\n\r\nBAD IVTC -\r\n\r\nAls IVTC (inverse telecine) bezeichnet man den Prozess des heruntekonvertierens eines Movies mit 30fps auf eine Framerate von 24fps um Platz zu sparen. Das Bild erscheint dem geschulten Auge dadurch unsauber, "holprig".\r\n\r\n\r\nDC -\r\n\r\nEin Film mit speziellen Szenen, die in der Urveröffentlichung nicht zu sehen waren. Bei vielen Filmen hat nicht der Regisseur das letzte Wort, sondern die Produzenten bestimmen, in welcher Schnittfassung ein Film in unsere Kinos kommt. Ein Regisseur, der mit der Kinoversion seines Films nicht einverstanden war, hat vielleicht später die Gelegenheit, eine Schnittfassung zu erstellen, die seinen Vorstellungen entspricht. Diese Fassung nennt man "Director''s Cut".\r\n\r\n\r\nDUBBED -\r\n\r\nOriginalton ist ersetzt worden (z.B. Ton aus einem deutschen Kino genommen und mit nem englischen Release gemixt) Mic.Dubbed = z.B.: engl. Release mit deutscher Tonspur versehen, die per Micro im Kino aufgenommen wurde Line.Dubbed = z.B.: engl. Release mit deutscher Tonspur versehen, die über den "Line"-Ausgang von einer externen Quelle im Kino aufgenommen wurde.\r\n\r\n\r\nDUPE -\r\n\r\nZweiter, späterer Release eines Titels einer anderen Releasegroup das keinen nennenswerten Qualitätsunterschied bietet.\r\n\r\n\r\nFS -\r\nDas Release ist Fullscreen, also Vollbild. Dabei wird die gesamte sichtbare Bildfläche ausgenutzt und somit schwarze Ränder vermieden.\r\n\r\n\r\nNUKE -\r\nEs gibt zwei arten des "nukings": Zum einen wird ein release von einer einzelnen Release-News-Seite genuked, weil es nicht ihren "Regeln" eines Ripps entspricht, zum anderen gibt es allgemeine nukes (von der gesamten Szene), wenn das Release DUPE, also doppelt released wurde, oder anderweitig irregulär ist.\r\n\r\n\r\nPD -\r\nDieses Release setzt sich bspw. aus einer "extern" bezogenen Bildquelle (z.B. von einer amerikanischen Releasegroup) und einer "eigenen" (selbst abgenommenen) deutschen Tonspur zusammen. Das ganze hält sich an sog. Pirate-Dub-Regeln, die exakt definieren, was ein Pirate Dub befolgen muss. Verstösse werden mit NUKE geahndet. Es sei gesagt, dass es sich hierbei um eine deutsche Regelung handelt, die jedoch nicht von allen deutschen Dub-Crews akzeptiert wird und somit nicht als Standart betrachtet werden kann.\r\n\r\n\r\nPS -\r\nPan and Scan: Filme, die für eine Auswertung im Kino gedreht wurden, haben ein Bildformat, das auf die rechteckige Kinoleinwand ausgerichtet ist. Wenn ein solcher Film nun für den Gebrauch auf dem heimischen Fernseher auf Video überspielt wird, ist eine Anpassung des Bildes notwendig, so dass es den viereckigen Fernsehbildschirm ausfüllt. Die meisten amerikanischen Filme, die nach 1955 entstanden sind, wurden im amerikanischen Breitwandformat von 1,85:1 gedreht (für die meisten europäischen Filme gilt das europäische Breitwandformat von 1,66:1). Ausgenommen ist das noch breitere Cinemascope-Format (2,35:1), für das eine anamorphotische Linse verwendet wird. Das Standard-Bildformat eines Fernsehgerätes beträgt dagegen 1,33:1. Beim Transfer auf Video wird das Bild also verkleinert. Dies geschieht dadurch, dass man das komplette Bild abfährt (der englische Begriff dafür ist "pan") und sich dann auf einen Bildausschnitt konzentriert. Die Breite des Bildes wird verringert, wobei ein Teil verloren geht. Wenn bei einem Video oder bei einer DVD keine Angaben zum Bildformat vorliegen und der Hinweis "Originalkinoformat" fehlt, muss man davon ausgehen, dass die Bildgröße dem Fernsehformat (1,33:1) durch das Pan and Scan-Verfahren angepasst wurde. Wer lieber das ganze Bild sehen möchte, sollte -- wenn es sie gibt -- auf Widescreen- bzw. Letterbox-Versionen zurückgreifen. Ein Vollbild-Release (vgl. *FS*) ist das Ergebnis aus dem Pan and Scan Verfahren.\r\n\r\n\r\nREPACK -\r\nBeim Packen des Release z.B. zu einem RAR-Archiv kam es zu Fehlern und das Archiv wies beim entpacken bspw. CRC-Fehler auf und wurde deshalb erneut gepackt und neu released.\r\n\r\n\r\nWS -\r\nEin Widescreen-Video versucht das gesamte Bild, so wie es im Kino zu sehen ist, auch auf dem Fernseher zu erhalten -- obwohlsich die Proportionen der Leinwand und des Fernsehschirms stark von einander unterscheiden. Eine Widescreen-Version behält die Ausmaße des Filmbildes bei (in den meisten Fällen 1,85:1), indem ober- und unterhalb des Bildes schwarze Balken hinzugefügt werden, die das rechteckige Format der Kinoleinwand simulieren. Es gibt unterschiedliche Breitwandformate, die diverse Zwischengrößen verwenden. Die Breite der schwarzen Balken ist daher immer vom tatsächlichen Bildformat der Kinokopie abhängig. Filme, die nicht im Widescreen- oder Letterbox-Format auf Video kopiert wurden, füllen den ganzen Bildschirm aus und wurden mit dem "Pan and Scan" -Verfahren bearbeitet. Gibt es von einem Film zwei Versionen auf Video, eine Vollbild- ("Pan and Scan") und eine Widescreen-Fassung, dann ist der Inhalt gleich. Die Titel unterscheiden sich nur in der Art, wie sie auf dem Fernsehbildschirm wiedergegeben werden.\r\n\r\n\r\nSUBBED -\r\nDieses Movie besitzt Untertitel. Dies kann von einem einzelnen, kleinen bis zu mehreren oder sehr grossen Untertiteln reichen, die je nach dem sehr viel Platz, i.d.R. am unteren Bildrand, einnehmen.\r\n', 29, 0, NULL, NULL),
(6, 'Failover IP einrichten', 'Öffne deine /etc/network/interfaces\r\n\r\nAnschließend fügst du am Ende der Datei das folgende ein:\r\n\r\nCode:\r\nauto eth0:0\r\niface eth0:0 inet static\r\naddress $DEINEFAILOVERIP\r\nnetmask 255.255.255.255\r\n\r\nDas wars schon. Jetzt noch ein \r\n\r\nCode:\r\n/etc/init.d/networking restart', 1, 0, NULL, NULL),
(7, 'Was sind Titten?', 'Die Titten sind wohl zwei der faszinierendsten Kapitel des evolutionären Bereichs der Menschheitsgeschichte, eventuell mal abgesehen von Albert Einstein (auch bekannt als ''The Brain'') und Kuh. Die Titte ist ein primäres Geschlechtsorgan der Steinmetzmuschel.\r\nWissenschaftlern zufolge gibt es etwa doppelt so viele Titten wie Frauen auf dieser Welt.\r\nEinem Gerücht zufolge unterliegen Titten im Laufe der Zeit immer mehr der Schwerkraft und werden deswegen nach unten gezogen. Meistens jedoch werden diese dicken Titten (die meistens in Rudeln von zwei Tieren vorkommen) von etwas namens T-Shirt verdeckt. Männliche Lebewesen versuchen oft diese T-Shirts zu entfernen, haben aber nicht immer Glück dabei.\r\n\r\nWichtige Charakteristika\r\n\r\nBeischlafvoraussetzung für Frauen mit heterosexuellen Männern.\r\nwerden fälschlicherweise häufig mit Talent oder Intelligenz gleichgesetzt (vgl. Barbara Schöneberger). Doch weder das eine, noch das andere könnte jemals ein paar ordentliche Titten ersetzen.\r\nbekommen manche Männer niemals in real zu sehen, da sie zu sehr z.B. mit World of Warcraft spielen beschäftigt sind\r\ninteressiert die tollsten Menschen der Welt oftmals nur geringfügig\r\nsehr schön\r\nunentbehrlich\r\nAuch gebräuchlich als Ausdruck der Freude.\r\nBeispiel: "Boah, gestern war voll Titte!" (vgl. dazu: South Park)\r\nAls Titten bezeichnet man auch das Material, das auf Männer anziehend wirkt. (Meistens zu 90% aus Silikon, 4% Styropor und 6% Taschentücher). Bei unprofessioneller Bearbeitung, kann der Gegeneffekt eintreten. In diesem Fall rennen die Männer weg, ohne dass sich unten was rührt.\r\nTitten sind wunderschön weich und toll, hoffentlich sehr groß und auch dafür verwendbar: Man drücke die zwei Titten zusammen, es entsteht im Brustkorbbereich ein Hohlraum. der sich zur Befriedigung männlicher Bedürfnisse eignet, nun haben wir einen Tittenfick.\r\n\r\nGefahren\r\n\r\nTitten sind nicht ungefährlich. Man muss vorsichtig mit ihnen umgehen. Es besteht Erstickungsgefahr! Manchmal kann es auch passieren, dass man anhand der Muttermilch ertrinkt.', 1, 0, NULL, NULL),
(8, 'Albert Einstein', 'Albert Einstein (* 14. März 1879 in Ulm; † 18. April 1955 in Princeton, New Jersey) war ein theoretischer Physiker. Seine Forschungen zur Struktur von Materie, Raum und Zeit sowie dem Wesen der Gravitation veränderten maßgeblich das physikalische Weltbild. Er gilt daher als einer der bedeutendsten Physiker aller Zeiten.[1]\r\n\r\nEinsteins Hauptwerk, die Relativitätstheorie, machte ihn weltberühmt. Im Jahr 1905 erschien seine Arbeit mit dem Titel Zur Elektrodynamik bewegter Körper, deren Inhalt heute als spezielle Relativitätstheorie bezeichnet wird. 1915 publizierte Einstein die allgemeine Relativitätstheorie. Auch zur Quantenphysik leistete er wesentliche Beiträge. „Für seine Verdienste um die theoretische Physik, besonders für seine Entdeckung des Gesetzes des photoelektrischen Effekts“, erhielt er den Nobelpreis des Jahres 1921, welcher ihm 1922 überreicht wurde. Seine theoretischen Arbeiten spielten – im Gegensatz zur verbreiteten Meinung – beim Bau der Atombombe und der Entwicklung der Kernenergie nur eine indirekte Rolle.[2]\r\n\r\nAlbert Einstein gilt als Inbegriff des Forschers und Genies. Er nutzte seine außerordentliche Bekanntheit auch außerhalb der naturwissenschaftlichen Fachwelt bei seinem Einsatz für Völkerverständigung und Frieden. In diesem Zusammenhang verstand er sich selbst als Pazifist, Sozialist und Zionist.\r\n\r\nIm Laufe seines Lebens war Einstein Staatsbürger mehrerer Länder: Durch Geburt besaß er die württembergische Staatsbürgerschaft. Von 1896 bis 1901 staatenlos, danach Staatsbürger der Schweiz, war er 1911/12 in Österreich-Ungarn auch Bürger Österreichs. Von 1914 bis 1932 lebte Einstein in Berlin und war als Bürger Preußens erneut Staatsangehöriger im Deutschen Reich. Mit der „Machtergreifung“ Hitlers gab er 1933 den deutschen Pass endgültig ab. Zu seinem seit 1901 geltenden Schweizer Bürgerrecht kam ab 1940 noch die amerikanische Staatsbürgerschaft.\r\n\r\n', 1, 0, NULL, NULL),
(9, 'Cake-Pops', 'Habt ihr schon mal von  Pops gehört? Diesen lustigen farbigen Kuchenkugeln am Stiel?\r\nCake-Pops, die ursprünglich aus Amerika kommen, sind seit einiger Zeit das Trendgebäck in Deutschland. Ob einfach mit Schokolglasur und bunten Streuseln verziert oder in kleine Kunstwerke verwandelt – wir haben für Euch die Basics rund ums Cake Pop backen zusammengetragen. Darunter findet ihr selbstverständlich auch bewährte Cake-Pops Rezepte.', 29, 0, 0, 1),
(11, 'Client: uTorrent einstellen', 'uTorrent (korrekte Schreibweise µTorrent) ist ein schneller, kleiner und sehr beliebter Filesharing Client der das Bittorrent Netzwerk nutzt. Das Programm hat eine sehr niedrige CPU Belastung wodurch es auch auf älteren Rechnern eingesetzt werden kann.\r\n\r\nMit einem Doppelklick auf die utorrent.exe geht es los. Das Language Pack sollte die Sprache automatisch auf Deutsch umstellen. Sollte dies nicht der Fall sein, kann man dies später ändern.\r\nZu Beginn kommt eine Abfrage ob utorrent eine Verknüpfung auf dem Desktop ablegen soll was wir bejahen.\r\n\r\n[img]http://power-castle.myftp.org/_x264_/bitbucket/08/pic-ff37effb9bceded493bffb3c9f0f2b85.gif[/img]\r\n\r\nAls nächstes wird gefragt ob uTorrent als Standardanwendung für torrent Dateien verwendet werden soll was wir auch bejahen.\r\n\r\n[img]http://power-castle.myftp.org/_x264_/bitbucket/08/pic-a294261defe9c7ccd3ccfcc72a03f0a3.gif[/img]\r\n\r\nDann sollte der SpeedGuide erscheinen, den wir aber erstmal wegklicken.\r\nSollte der SpeedGuide nicht erscheinen, dann ist das auch ok.\r\n\r\nWenn die Sprache nicht auf Deutsch eingestellt ist, dann müsst ihr das noch ändern. Oben links auf „Options„, dann auf „Preferences“ klicken:\r\n\r\n[img]http://power-castle.myftp.org/_x264_/bitbucket/08/pic-34fc773c9f4eca42e9526e3d1d452df0.gif[/img]\r\n\r\nDann auf „Language“ und „German“ klicken:\r\n\r\n[img]http://power-castle.myftp.org/_x264_/bitbucket/08/pic-88cc52a8b4b7b25870df431633228d23.gif[/img]\r\n\r\nDann unten mit „Apply“ und „OK“ bestätigen. Jetzt muss uTorrent neugestartet werden und alles sollte auf Deutsch zu sehen sein. Selbstverständlich funktioniert dies auch mit anderen Sprachen.\r\n\r\nGeschwindigkeit / Ports\r\n\r\nAls nächstes stellen wir die Geschwindigkeit ein. Dies ist natürlich abhängig von eurem Internetzugang. Die Werte sehen standardmäßig folgendermaßen aus:\r\n\r\nDSL 1000 (1024 kbit/s Download – 128 kbit/s Upload): ca. 16 kbyte/s Upload max\r\nDSL 2000 (2048 kbit/s Download – 192 kbit/s Upload): ca. 24 kbyte/s Upload max\r\nDSL 3000 (3096 kbit/s Download – 384 kbit/s Upload): ca. 40 kbyte/s Upload max\r\nDSL 6000 (6016 kbit/s Download – 576 kbit/s Upload): ca. 72 kbyte/s Upload max\r\nDSL 16000 (16000 kbit/s Download – 1024 kbit/s Upload): ca. 125 kbyte/s Upload max\r\n\r\nDiese Werte sind von der Telekom. Falls ihr bei einem anderen Provider seid, dann können die Zahlen auch abweichen (meistens sind sie aber gleich). Falls ihr euch nicht sicher seid, dann könnt ihr auch einen Speedtest mit Klick auf „Führe Speed-Test auf ww.dslreports.com aus“ durchführen.\r\n\r\nUm den Speed einzustellen müsst ihr in uTorrent auf „Optionen“ und dann auf „Speed Guide“ klicken. Dort wählt ihr dann eure Geschwindigkeit aus, wobei der zweite Wert für den Upload steht. Der Downloadspeed ist nicht wichtig da er im Normalfall nicht begrenzt wird. uTorrent wählt automatisch den optimalen Uploadwert für eure Leitung damit das surfen nicht behindert wird.\r\n\r\n[img]http://power-castle.myftp.org/_x264_/bitbucket/08/pic-731e2b7598e7529e0890df896485c919.gif[/img]\r\n\r\nAls nächstes führen wir einen Porttest durch. Was ein Port ist und welche Werte wichtig sind, könnt ihr hier nachlesen.\r\nEs ist wichtig, dass der Port richtig weitergeleitet wird. Nur so bekommt ihr den maximal möglichen Speed beim Download. Dazu klickt ihr einfach auf Test der Portweiterleitung\r\n\r\n[img]http://power-castle.myftp.org/_x264_/bitbucket/08/pic-fe02878e99a84d98181e45199dd8b082.gif[/img]\r\n\r\nDer Test MUSS ein OK! ergeben. Ein Browserfenster sollte aufgehen und es sollte folgendes erscheinen (natürlich mit anderen Zahlen):\r\n\r\n[img]http://power-castle.myftp.org/_x264_/bitbucket/08/pic-df6e7fe5f5466d3f879fbfa627aba040.gif[/img]\r\n\r\nBenutzer bei denen ein OK! Fenster geöffnet wurde, müssen folgende Einstellungen nicht vornehmen!\r\n\r\nSollte ein Error! Fenster auftauchen, dann gibt es ein Problem. Entweder ihr benutzt einen Router oder eine Firewall (oder beides).\r\n\r\nVersucht zunächst das „UPnP Port Mapping“ (siehe nächstes Bild) zu aktivieren (bei utorrent UND eurem Router). Viele neue Router unterstützen diese Funktion. Danach müsst ihr den Porttest nochmal durchführen. Falls ein OK! erscheint ist alles klar, ansonsten müsste ihr die Ports manuell weiterleiten.\r\n\r\nDazu notiert ihr euch erstmal den Port der bei euch für uTorrent zuständig ist (in unserem Beispiel 42993). Der Port kann auch zufällig ausgewählt werden unter „Optionen“ -> „Einstellungen“ -> „Netzwerk“ -> rechts auf „Zufälliger Port“ klicken. Wichtig ist auch, dass die Optionen wie auf dem Bild eingestellt sind (UPnP in diesem Fall deaktivieren!):\r\n\r\n[img]http://power-castle.myftp.org/_x264_/bitbucket/08/pic-dcb50c25f66c7e61353bf1b59fae5ecc.gif[/img]\r\n\r\nDie Portfreigabe an sich ist etwas kompliziert, da es einfach zu viele Router und Firewalls gibt. D.h. ich kann hier nicht für alle Geräte / Software zeigen wie es funktioniert.\r\nBei der FRITZ!Box sieht es folgendermaßen aus:\r\nIhr klickt auf „Einstellungen„, „Internet“ -> „Portfreigabe“ -> „Neue Portfreigabe“ und stellt folgendes ein (als Port natürlich den Wert eintragen den ihr unter „zufälliger Port“ ausgewählt habt)\r\n\r\n[img]http://power-castle.myftp.org/_x264_/bitbucket/08/pic-cc1abddbfcfdb6dafe3da1bf35a2b86c.gif[/img]\r\n\r\n[img]http://power-castle.myftp.org/_x264_/bitbucket/08/pic-199ca9d7863fc087498478a77a459177.gif[/img]\r\n\r\nMit IP Adresse ist hier nicht eure IP im Internet gemeint, sondern die IP im Router! Diese kann bei der FRITZ!Box unter „System“ -> „Netzwerkgeräte“ ausgelesen werden.\r\n\r\nJetzt müsst ihr wieder in uTorrent testen ob der Port ein OK! anzeigt (SpeedGuide -> Test der Portweiterleitung).\r\nFalls ihr einen anderen Router/Firewall benutzt, müsst ihr versuchen den uTorrent Port per TCP freizugeben. Vielleicht findet ihr auf der Herstellerseite eures Routers/Firewall mehr Hinweise dazu.\r\n\r\n', 1, 0, 0, 1);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `accounts`
--
ALTER TABLE `accounts`
 ADD PRIMARY KEY (`userid`,`chash`);

--
-- Indizes für die Tabelle `addedrequests`
--
ALTER TABLE `addedrequests`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `admincat`
--
ALTER TABLE `admincat`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `admincp`
--
ALTER TABLE `admincp`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `admincpanz`
--
ALTER TABLE `admincpanz`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `admin_categories`
--
ALTER TABLE `admin_categories`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `admin_questions`
--
ALTER TABLE `admin_questions`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `agents`
--
ALTER TABLE `agents`
 ADD PRIMARY KEY (`agent_id`), ADD UNIQUE KEY `agent_name` (`agent_name`);

--
-- Indizes für die Tabelle `attachmentdownloads`
--
ALTER TABLE `attachmentdownloads`
 ADD PRIMARY KEY (`id`), ADD KEY `fileid_userid` (`fileid`,`userid`);

--
-- Indizes für die Tabelle `attachments`
--
ALTER TABLE `attachments`
 ADD PRIMARY KEY (`id`), ADD KEY `topicid` (`topicid`), ADD KEY `postid` (`postid`);

--
-- Indizes für die Tabelle `avps`
--
ALTER TABLE `avps`
 ADD PRIMARY KEY (`arg`);

--
-- Indizes für die Tabelle `bans`
--
ALTER TABLE `bans`
 ADD PRIMARY KEY (`id`), ADD KEY `first_last` (`first`,`last`);

--
-- Indizes für die Tabelle `betting_games`
--
ALTER TABLE `betting_games`
 ADD PRIMARY KEY (`gid`);

--
-- Indizes für die Tabelle `blocks`
--
ALTER TABLE `blocks`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `userfriend` (`userid`,`blockid`);

--
-- Indizes für die Tabelle `bonus`
--
ALTER TABLE `bonus`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `bootstrap_design`
--
ALTER TABLE `bootstrap_design`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `comments`
--
ALTER TABLE `comments`
 ADD PRIMARY KEY (`id`), ADD KEY `user` (`user`), ADD KEY `torrent` (`torrent`);

--
-- Indizes für die Tabelle `completed`
--
ALTER TABLE `completed`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `config`
--
ALTER TABLE `config`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `countries`
--
ALTER TABLE `countries`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `downloadtickets`
--
ALTER TABLE `downloadtickets`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `faq_categories`
--
ALTER TABLE `faq_categories`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `faq_questions`
--
ALTER TABLE `faq_questions`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `files`
--
ALTER TABLE `files`
 ADD PRIMARY KEY (`id`), ADD KEY `torrent` (`torrent`);

--
-- Indizes für die Tabelle `forums`
--
ALTER TABLE `forums`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `forum_cats`
--
ALTER TABLE `forum_cats`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `forum_pollanswers`
--
ALTER TABLE `forum_pollanswers`
 ADD PRIMARY KEY (`id`), ADD KEY `pollid` (`pollid`), ADD KEY `userid` (`userid`), ADD KEY `selection` (`selection`);

--
-- Indizes für die Tabelle `forum_polls`
--
ALTER TABLE `forum_polls`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `friends`
--
ALTER TABLE `friends`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `userfriend` (`userid`,`friendid`);

--
-- Indizes für die Tabelle `img_host`
--
ALTER TABLE `img_host`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `invites`
--
ALTER TABLE `invites`
 ADD PRIMARY KEY (`id`), ADD KEY `inviter` (`id`);

--
-- Indizes für die Tabelle `jamescat`
--
ALTER TABLE `jamescat`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `jamestext`
--
ALTER TABLE `jamestext`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `lotto_abonnement`
--
ALTER TABLE `lotto_abonnement`
 ADD PRIMARY KEY (`abo_id`), ADD KEY `userID` (`abo_userID`);

--
-- Indizes für die Tabelle `lotto_aboPacks`
--
ALTER TABLE `lotto_aboPacks`
 ADD PRIMARY KEY (`aboPack_id`);

--
-- Indizes für die Tabelle `lotto_config`
--
ALTER TABLE `lotto_config`
 ADD PRIMARY KEY (`lottery_winHour`);

--
-- Indizes für die Tabelle `lotto_stats`
--
ALTER TABLE `lotto_stats`
 ADD PRIMARY KEY (`stats_id`), ADD KEY `stats_userID` (`stats_userID`);

--
-- Indizes für die Tabelle `menu`
--
ALTER TABLE `menu`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `messages`
--
ALTER TABLE `messages`
 ADD PRIMARY KEY (`id`), ADD KEY `receiver` (`receiver`);

--
-- Indizes für die Tabelle `modcomments`
--
ALTER TABLE `modcomments`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `news`
--
ALTER TABLE `news`
 ADD PRIMARY KEY (`id`), ADD KEY `added` (`added`);

--
-- Indizes für die Tabelle `overspeed`
--
ALTER TABLE `overspeed`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `partner`
--
ALTER TABLE `partner`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `peers`
--
ALTER TABLE `peers`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `torrent_peer_id` (`torrent`,`peer_id`), ADD KEY `torrent` (`torrent`), ADD KEY `torrent_seeder` (`torrent`,`seeder`), ADD KEY `last_action` (`last_action`), ADD KEY `connectable` (`connectable`), ADD KEY `userid` (`userid`);

--
-- Indizes für die Tabelle `pmfolders`
--
ALTER TABLE `pmfolders`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `pollsnew`
--
ALTER TABLE `pollsnew`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `pollsnewsettings`
--
ALTER TABLE `pollsnewsettings`
 ADD KEY `id` (`id`);

--
-- Indizes für die Tabelle `pollsnewvotes`
--
ALTER TABLE `pollsnewvotes`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `postthanks`
--
ALTER TABLE `postthanks`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `privatechat`
--
ALTER TABLE `privatechat`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `p_news`
--
ALTER TABLE `p_news`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `ratings`
--
ALTER TABLE `ratings`
 ADD PRIMARY KEY (`torrent`,`user`), ADD KEY `user` (`user`);

--
-- Indizes für die Tabelle `ratiostats`
--
ALTER TABLE `ratiostats`
 ADD PRIMARY KEY (`userid`,`timecode`,`type`);

--
-- Indizes für die Tabelle `readposts`
--
ALTER TABLE `readposts`
 ADD PRIMARY KEY (`id`), ADD KEY `userid` (`id`);

--
-- Indizes für die Tabelle `requestcomments`
--
ALTER TABLE `requestcomments`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `requests`
--
ALTER TABLE `requests`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `reseed`
--
ALTER TABLE `reseed`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `rules_categories`
--
ALTER TABLE `rules_categories`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `rules_questions`
--
ALTER TABLE `rules_questions`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `shoutbox`
--
ALTER TABLE `shoutbox`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `sitelog`
--
ALTER TABLE `sitelog`
 ADD PRIMARY KEY (`id`), ADD KEY `added` (`added`);

--
-- Indizes für die Tabelle `slot_machine_tp`
--
ALTER TABLE `slot_machine_tp`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `smilies`
--
ALTER TABLE `smilies`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `staffmessages`
--
ALTER TABLE `staffmessages`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `staffrules_categories`
--
ALTER TABLE `staffrules_categories`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `staffrules_questions`
--
ALTER TABLE `staffrules_questions`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `teambox`
--
ALTER TABLE `teambox`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `teammembers`
--
ALTER TABLE `teammembers`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `teams`
--
ALTER TABLE `teams`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `thanks`
--
ALTER TABLE `thanks`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `topics`
--
ALTER TABLE `topics`
 ADD PRIMARY KEY (`id`), ADD KEY `userid` (`userid`), ADD KEY `subject` (`subject`), ADD KEY `lastpost` (`lastpost`);

--
-- Indizes für die Tabelle `torrents`
--
ALTER TABLE `torrents`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `info_hash` (`info_hash`), ADD KEY `owner` (`owner`), ADD KEY `visible` (`visible`), ADD KEY `category_visible` (`category`,`visible`), ADD FULLTEXT KEY `ft_search` (`search_text`,`ori_descr`);

--
-- Indizes für die Tabelle `traffic`
--
ALTER TABLE `traffic`
 ADD PRIMARY KEY (`userid`,`torrentid`);

--
-- Indizes für die Tabelle `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `username` (`username`), ADD KEY `status_added` (`status`,`added`), ADD KEY `ip` (`ip`), ADD KEY `uploaded` (`uploaded`), ADD KEY `downloaded` (`downloaded`), ADD KEY `country` (`country`), ADD KEY `last_access` (`last_access`), ADD KEY `enabled` (`enabled`), ADD KEY `warned` (`warned`);

--
-- Indizes für die Tabelle `votes`
--
ALTER TABLE `votes`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `wiki`
--
ALTER TABLE `wiki`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `addedrequests`
--
ALTER TABLE `addedrequests`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `admincat`
--
ALTER TABLE `admincat`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT für Tabelle `admincp`
--
ALTER TABLE `admincp`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=88;
--
-- AUTO_INCREMENT für Tabelle `admincpanz`
--
ALTER TABLE `admincpanz`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=95;
--
-- AUTO_INCREMENT für Tabelle `admin_categories`
--
ALTER TABLE `admin_categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT für Tabelle `admin_questions`
--
ALTER TABLE `admin_questions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT für Tabelle `agents`
--
ALTER TABLE `agents`
MODIFY `agent_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=138;
--
-- AUTO_INCREMENT für Tabelle `attachmentdownloads`
--
ALTER TABLE `attachmentdownloads`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `attachments`
--
ALTER TABLE `attachments`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `bans`
--
ALTER TABLE `bans`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=83;
--
-- AUTO_INCREMENT für Tabelle `betting_games`
--
ALTER TABLE `betting_games`
MODIFY `gid` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `blocks`
--
ALTER TABLE `blocks`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT für Tabelle `bonus`
--
ALTER TABLE `bonus`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT für Tabelle `bootstrap_design`
--
ALTER TABLE `bootstrap_design`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT für Tabelle `categories`
--
ALTER TABLE `categories`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=89;
--
-- AUTO_INCREMENT für Tabelle `comments`
--
ALTER TABLE `comments`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT für Tabelle `completed`
--
ALTER TABLE `completed`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `config`
--
ALTER TABLE `config`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=176;
--
-- AUTO_INCREMENT für Tabelle `countries`
--
ALTER TABLE `countries`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT für Tabelle `downloadtickets`
--
ALTER TABLE `downloadtickets`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `faq_categories`
--
ALTER TABLE `faq_categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT für Tabelle `faq_questions`
--
ALTER TABLE `faq_questions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT für Tabelle `files`
--
ALTER TABLE `files`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `forums`
--
ALTER TABLE `forums`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT für Tabelle `forum_cats`
--
ALTER TABLE `forum_cats`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT für Tabelle `forum_pollanswers`
--
ALTER TABLE `forum_pollanswers`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT für Tabelle `forum_polls`
--
ALTER TABLE `forum_polls`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `friends`
--
ALTER TABLE `friends`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=108;
--
-- AUTO_INCREMENT für Tabelle `img_host`
--
ALTER TABLE `img_host`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1843;
--
-- AUTO_INCREMENT für Tabelle `invites`
--
ALTER TABLE `invites`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `jamescat`
--
ALTER TABLE `jamescat`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=153;
--
-- AUTO_INCREMENT für Tabelle `jamestext`
--
ALTER TABLE `jamestext`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT für Tabelle `lotto_abonnement`
--
ALTER TABLE `lotto_abonnement`
MODIFY `abo_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT für Tabelle `lotto_aboPacks`
--
ALTER TABLE `lotto_aboPacks`
MODIFY `aboPack_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT für Tabelle `lotto_stats`
--
ALTER TABLE `lotto_stats`
MODIFY `stats_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=785;
--
-- AUTO_INCREMENT für Tabelle `menu`
--
ALTER TABLE `menu`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=183;
--
-- AUTO_INCREMENT für Tabelle `messages`
--
ALTER TABLE `messages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT für Tabelle `modcomments`
--
ALTER TABLE `modcomments`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT für Tabelle `news`
--
ALTER TABLE `news`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=95;
--
-- AUTO_INCREMENT für Tabelle `overspeed`
--
ALTER TABLE `overspeed`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `partner`
--
ALTER TABLE `partner`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=85;
--
-- AUTO_INCREMENT für Tabelle `peers`
--
ALTER TABLE `peers`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `pmfolders`
--
ALTER TABLE `pmfolders`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT für Tabelle `pollsnew`
--
ALTER TABLE `pollsnew`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT für Tabelle `pollsnewsettings`
--
ALTER TABLE `pollsnewsettings`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `pollsnewvotes`
--
ALTER TABLE `pollsnewvotes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `postthanks`
--
ALTER TABLE `postthanks`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `privatechat`
--
ALTER TABLE `privatechat`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `p_news`
--
ALTER TABLE `p_news`
MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT für Tabelle `readposts`
--
ALTER TABLE `readposts`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `requestcomments`
--
ALTER TABLE `requestcomments`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT für Tabelle `requests`
--
ALTER TABLE `requests`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=108;
--
-- AUTO_INCREMENT für Tabelle `reseed`
--
ALTER TABLE `reseed`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT für Tabelle `rules_categories`
--
ALTER TABLE `rules_categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT für Tabelle `rules_questions`
--
ALTER TABLE `rules_questions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT für Tabelle `shoutbox`
--
ALTER TABLE `shoutbox`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `sitelog`
--
ALTER TABLE `sitelog`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=204;
--
-- AUTO_INCREMENT für Tabelle `slot_machine_tp`
--
ALTER TABLE `slot_machine_tp`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT für Tabelle `smilies`
--
ALTER TABLE `smilies`
MODIFY `id` int(3) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=136;
--
-- AUTO_INCREMENT für Tabelle `staffmessages`
--
ALTER TABLE `staffmessages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `staffrules_categories`
--
ALTER TABLE `staffrules_categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `staffrules_questions`
--
ALTER TABLE `staffrules_questions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `teambox`
--
ALTER TABLE `teambox`
MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT für Tabelle `teammembers`
--
ALTER TABLE `teammembers`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `teams`
--
ALTER TABLE `teams`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `thanks`
--
ALTER TABLE `thanks`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `topics`
--
ALTER TABLE `topics`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `torrents`
--
ALTER TABLE `torrents`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT für Tabelle `votes`
--
ALTER TABLE `votes`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=115;
--
-- AUTO_INCREMENT für Tabelle `wiki`
--
ALTER TABLE `wiki`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
